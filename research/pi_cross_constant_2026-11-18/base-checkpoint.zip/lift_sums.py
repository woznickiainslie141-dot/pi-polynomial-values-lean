"""Independent finite prime integral by intersecting integer lifts with the residue interval."""
from fractions import Fraction as F
from math import floor


def excess(s,m):
    if s<0:s=m-s
    if s<=m:return 0
    q,r=divmod(s,m)
    return m*q*(q-1)//2+r*q


def intersection_values(n,step,even,odd,parity):
    den=10000*step;end=den//2
    jumps={0:0,end:0};full=0
    for t_parity,widths in enumerate((even,odd)):
        p=(t_parity-parity)%2
        for w in widths:
            lim=n*w
            # Entire lifts satisfy -lim <= den*h <= lim-end.
            a=-(lim//den);b=(lim-end)//den
            if a<=b:
                full+=(b-p)//2-(a-1-p)//2
            left=-((lim+end)//den);right=lim//den
            partial=set(range(left,a))|set(range(b+1,right+1))
            for h in partial:
                if h%2!=p:continue
                l,r=max(0,-lim-h*den),min(end,lim-h*den)
                if l<r:
                    jumps[l]=jumps.get(l,0)+1;jumps[r]=jumps.get(r,0)-1
    prev=0;v=full;out=[]
    for x in sorted(jumps):
        if x>prev:out.append((x-prev,v))
        prev=x;v+=jumps[x]
    assert sum(l for l,v in out)==end
    return out


def validate_flat(classes,a,start):
    L=sum(a);V=len(a)//2
    q=[0]*len(a)
    for r in range(4):
        ids=sorted((i for i in range(len(a)) if (i-V)%4==r),key=lambda i:-a[i])
        for j,i in enumerate(ids):q[i]=j
    cols=[(F(w,20000),j) for band in classes for j,w in enumerate(band) if w]
    c=(sum(w*j for w,j in cols)-sum(v*j for v,j in zip(a,q)))/L
    assert c>F(excess(-2*len(classes[0]),len(a)),start)/L
    lo,hi=F(1,30),F(1,start)
    for h in range(1,2+max(max(q)+floor(max(a)/lo),max(j+floor(w/lo) for w,j in cols))):
        def tail(pairs,y):return sum(max(0,w-max(0,h-j)*y) for w,j in pairs)
        rows=list(zip(a,q))
        knots={lo,hi,*(w/(h-j) for w,j in rows+cols if h>j and lo<w/(h-j)<hi)}
        assert all(tail(rows,y)>=tail(cols,y) for y in knots)


def prime_saving(d,classes,a):
    L=sum(a);M=len(a);start=5 if d==2 else 8
    validate_flat(classes,a,start)
    value=0;scale=10**20;ev,od=classes[:2]
    for lo,hi,step in [(start,40,1024),(40,100,256),(100,280,64)]:
        vals=[(v.numerator,v.denominator*step) for v in a]
        def row(n):return sum(n*p//q for p,q in vals)
        for n in range(lo*step,hi*step+1):
            total=[]
            for e in range(2):total+=intersection_values(n,step,ev,od,e)
            # A single endpoint contributes the positive tail to its right slab
            # and the negative tail to its left slab; round each down separately.
            for i,H,upper in ((n,row(n+1),True),(n-1,row(n-1),False)):
                if i<lo*step or i>=hi*step:continue
                Z=sum(l*excess(v-H,M) for l,v in total if (v-H>M if upper else v-H<0))
                if Z:
                    value+=scale*Z*step*(2*i+1)*L.denominator//(20000*L.numerator*(i*(i+1))**2)
    return F(value,scale)

