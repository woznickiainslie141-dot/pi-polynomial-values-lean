"""Recompute the four mesh comparisons and both final auxiliary determinants from raw data."""
import argparse
import json
from fractions import Fraction as F
from pathlib import Path
from math import ceil
from spatial import HERE,PRIOR,Spatial,read
from compare import compare,evaluate,prove,sources
from parity import parameters
from parity_windows import finite
from partitions import check as check_partition


def direct(d,design,out,tab):
    data,_=sources(d);spec=read(PRIOR/f"center{d}.json")
    initial={r["label"]:r["field"] for r in data["witness"]["knots"]}
    wanted={tag for _,_,mix in tab["allocation"] for tag,n in mix}|{"scalar-0"}
    assert set(out["ordinary"])==wanted and set(out["tilted"])==wanted&set(spec["price"])
    data=dict(data,z=design["z"],witness=dict(data["witness"],knots=[]))
    for tag,row in out["ordinary"].items():
        assert row["label"]==tag
        if tag in initial:assert row["field"]==initial[tag]
        else:assert tag.startswith("mid-")
        data["witness"]["knots"].append({"label":tag,"field":row["field"]})
    classes,a,L,D,G,facts=parameters(d,design)
    saving=finite(d,classes,a);G-=saving
    model=Spatial(d,classes,a,spec["price"])
    U={tag:model.bound(r)[0] for tag,r in out["ordinary"].items()}
    P=dict(U)
    for tag,row in out["tilted"].items():
        assert row["label"]==tag and row["field"]==out["ordinary"][tag]["field"]
        P[tag]=model.bound(row)[1]
    rec=evaluate(d,data,tab,spec,classes,design["a"],D,G,(U,P,{}))
    facts.update(prime_saving=str(saving),final_prime_upper=str(G))
    return rec,facts


def check_original_prefix(d, design):
    # The balanced controls also satisfy the original four-residue prefix lemma.
    widths = [F(x, 10000) for x in design["even"]]
    assert design["even"] == design["odd"]
    ratios = design["a"]
    L = 2*sum(widths)
    V = len(ratios)-1
    mass = {v:L*ratios[abs(v)]/(2*sum(ratios)-ratios[0]) for v in range(-V,V+1)}
    groups = [sorted((a for v,a in mass.items() if v%4==l),reverse=True) for l in range(4)]
    gaps = [sum(sum(g[:j+1]) for g in groups)-2*sum(widths[:j+1]) for j in range(len(widths))]
    assert gaps[-1] == 0 and min(gaps[:-1]) == {2:F(423,1250),3:F(1917,5000)}[d]


def retained(d,mode,uniform):
    obj=uniform if mode=="uniform320" else read(HERE/f"{mode}-{d}.json")
    fractions=check_partition(obj,uniform,mode)
    return dict(intervals=len(obj["ordinary"][0]["edges"])-1,
                zero_field_energy_fraction=fractions["scalar-0"],
                min_field_fraction=str(min(map(F,fractions.values()))),
                max_field_fraction=str(max(map(F,fractions.values()))))


def main():
    if not __debug__: raise RuntimeError("Enable Python assertions.")
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--json",type=Path)
    args=parser.parse_args();out=[]
    modes=["uniform320","local200","local320","local400"]
    for d in (2,3):
        comparison=compare(d,modes,True)
        uni=read(HERE/f"uniform320-{d}.json")
        comparison["partition_checks"]={k:retained(d,k,uni) for k in modes}
        pool=read(HERE/f"final-fields{d}.json");tab=read(HERE/f"angles{d}.json")
        parity=read(HERE/f"design{d}.json");balanced=read(HERE/f"balanced{d}.json")
        assert parity["even"]!=parity["odd"]
        assert balanced["even"]==balanced["odd"] and parity["a"]==balanced["a"] and parity["z"]==balanced["z"]
        assert all(2*t==x+y for t,x,y in zip(balanced["even"],parity["even"],parity["odd"],strict=True))
        check_original_prefix(d, balanced)
        base=F(comparison["checkpoint"])
        for name,design in (("parity",parity),("balanced",balanced)):
            rec,facts=direct(d,design,pool,tab)
            evidence=prove(d,rec,F(design["C"]),F(design["b"]))
            assert F(evidence["omega"])<min(F(comparison["stages"]["local400"]["threshold"][0]),base)
            comparison[name]=dict(constants=rec,arithmetic=facts,endpoint=evidence)
            print(d,name,evidence["omega"],"margin >=",evidence["margin_lower"],flush=True)
        out.append(comparison)
    if args.json:
        args.json.write_text(json.dumps(dict(status="passed",cases=out),indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":main()

