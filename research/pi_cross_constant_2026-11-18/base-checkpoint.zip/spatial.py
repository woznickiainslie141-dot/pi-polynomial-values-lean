"""Directed integer enclosures for uniform or locally refined logarithmic-energy duals."""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PRIOR=HERE/"prior"
sys.path.insert(0,str(PRIOR))
from run_certificate import read
from center import endpoint_fields
from energy import primitives as old_tables

N=40000
GRID=640
UNIT=100000
S1=10**9
S2=10**12


@lru_cache(None)
def tables():
    scale=10**23
    logs=[(0,0),(0,0)]
    for k in range(1,2*N):
        w=2*k+1; den=w; odd=1;lo,hi=logs[-1]
        while (a:=2*scale//(odd*den)):
            lo+=a;hi+=a+1
            odd+=2;den*=w*w
        logs.append((lo,hi+2))
    first=[0];second=[0]
    for k in range(1,2*N+1):
        low=logs[k][0]+logs[2][0]-logs[N][1]
        high=logs[k][1]+logs[2][1]-logs[N][0]
        f=k*S1*(low-scale)//(N*scale)
        j=k*k*S2*(2*low-3*scale)//(4*N*N*scale)
        assert (f+2)*N*scale>=k*S1*(high-scale) and (j+2)*4*N*N*scale>=k*k*S2*(2*high-3*scale)
        first.append(f);second.append(j)
    return np.array([-v for v in first[:0:-1]]+first,dtype=np.int64),np.array(second,dtype=np.int64)


@lru_cache(None)
def precedent_anchor(d):
    data=read(PRIOR/"reference"/f"case{d}.json")
    spec=read(PRIOR/f"center{d}.json");fine=read(PRIOR/f"spatial{d}.json")
    witness=dict(bins=160,unit=UNIT,knots=[r for r in fine["ordinary"] if r["label"]==spec["anchor"]])
    assert spec["anchor_bins"]==160 and len(witness["knots"])==1
    field=next(endpoint_fields(dict(data,witness=witness),old_tables()[0]))[1]
    old=(field[:-1]+field[1:]).argmax(axis=1)
    return np.repeat(old,N//10000)


def square(seams,delta):
    _,tw=tables()
    ids=np.flatnonzero(delta)
    x=seams[ids]; c=delta[ids]
    gram=tw[abs(x[:,None]-x)]
    high,low=np.divmod(gram,10**6)
    norm=sum(map(abs,map(int,c)))
    assert norm*max(int(np.abs(high).max(initial=0)),10**6) < 2**62
    def value(mat):
        return sum(int(a)*int(b) for a,b in zip(c,mat@c))
    return value(high)*10**6+value(low),norm


def product(basis,coef):
    """Exact dot products in binary64 by splitting integer coefficients if needed."""
    top=int(np.abs(basis).max()); norm=max(map(int,np.abs(coef).sum(axis=1)))
    assert top*norm < 2**61
    if top*norm<2**52:
        return (basis@coef.T.astype(float)).astype(np.int64)
    radix=1024
    high,low=np.divmod(coef,radix)
    assert top*max(int(np.abs(high).sum(axis=1).max()),int(low.sum(axis=1).max()))<2**52
    return (basis@high.T.astype(float)).astype(np.int64)*radix+(basis@low.T.astype(float)).astype(np.int64)


def step_counts(class_widths):
    # Widths of each of the four t mod 4 classes are measured in 1/10000.
    w=np.array(class_widths,dtype=np.int64)*(N//10000)
    assert w.shape[0]==4 and (w[:,0]==N).all() and np.all(np.diff(w,axis=1)<=0)
    x=np.arange(1,N+1)[:,None]
    total=(x<=w.reshape(-1)).sum(axis=1)
    positive=(x<=w[:,1:].reshape(-1)).sum(axis=1)
    return total,positive


class Spatial:
    def __init__(self,d,classes,masses,prices):
        self.L=sum(masses);self.masses=masses
        self.classes=classes;self.prices=prices;self.anchor=precedent_anchor(d)
        self.weight,self.jet=step_counts(classes)
        assert F(sum(map(int,self.weight)),2*N)==self.L
        self.edges=np.arange(-N,N+1,2*N//GRID,dtype=np.int64)
        self.x=np.arange(N+1,dtype=np.int64)
        self.basis=tables()[0][2*N+self.x[:,None]-self.edges].astype(float)
        self.union=np.unique(np.r_[self.edges,*(np.r_[-np.array(ws),ws]*(N//10000) for ws in classes)])
        mid=self.union[1:]+self.union[:-1]
        self.nu4=sum((abs(mid[:,None])<2*np.asarray(ws)*(N//10000)).sum(axis=1) for ws in classes)
        self.index=np.searchsorted(2*self.edges,mid)-1

    def bound(self,row):
        edges=row["edges"]; unit=UNIT; m=len(self.masses)
        assert edges[0]==0 and edges[-1]==GRID and all(type(i) is int for i in edges)
        assert all(b>a for a,b in zip(edges,edges[1:])) and edges==[GRID-i for i in edges[::-1]]
        assert len(row["field"])==len(row["b"])==(m+1)//2 and row["field"][0]==0
        assert all(len(line)==len(edges)-1 for line in row["density"]) and len(row["density"])==(m+1)//2
        for line in [*row["density"],row["field"],row["b"]]:
            assert all(type(v) is int and abs(v)<10**8 for v in line)
        rho=np.array(row["density"],dtype=np.int64)
        assert np.array_equal(rho[0],rho[0,::-1])
        rho=np.r_[rho[:0:-1,::-1],rho]
        delta=np.diff(np.pad(rho,((0,0),(1,1))),axis=1)
        norm=np.abs(delta).sum(axis=1)
        b=np.array(row["b"][:0:-1]+row["b"],dtype=np.int64)
        k=np.array(row["field"],dtype=np.int64);k=np.r_[-k[:0:-1],k]
        ix=np.array(edges,dtype=np.int64)
        coef=np.zeros((m,GRID+1),dtype=np.int64);coef[:,ix]=delta
        field=product(self.basis,coef)
        assert 2*(int(np.abs(field).max())+S1*(int(np.abs(k).max())+int(np.abs(b).max()))+2*int(norm.max()))<2**62
        field+=(S1//N)*self.x[:,None]*k-S1*b+2*norm
        env=field.max(axis=1)
        trap=sum(int(w)*(int(l)+int(r)) for w,l,r in zip(self.weight,env,env[1:]))
        error=F(int(self.weight.max())*int(np.abs(delta).max(axis=0).sum()),4*unit)*F(5+(2*N).bit_length(),4*N*N)
        sq=0
        for c in delta:
            form,total=square(self.edges[ix],c)
            sq+=form+2*total**2
        # The residual density uses denominator 4*unit for unequal residue widths.
        full=np.repeat(rho.sum(axis=0),np.diff(ix))
        residual=unit*self.nu4-4*full[self.index]
        signed=np.diff(np.pad(residual,1))
        form,total=square(self.union,signed)
        correction=min(F(0),F(-form+2*total**2,S2*(4*unit)**2))/(2*m*self.L)
        U=(F(trap,4*N*unit*S1)+error+F(sq,2*S2*unit**2)
           +sum(a*int(v) for a,v in zip(self.masses,b))/unit)/self.L+correction
        price=self.prices.get(row["label"],0)
        if not price:
            return U,U
        assert type(price) is int and 0<price<10**8
        cost=price*(unit*S1//10**7)
        best=field.argmax(axis=1);second=np.partition(field,-2,axis=1)[:,-2]
        gap=env-second
        left=np.maximum(0,cost-np.where(best[:-1]==self.anchor,gap[:-1],0))
        right=np.maximum(0,cost-np.where(best[1:]==self.anchor,gap[1:],0))
        inc=sum(int(w)*(int(l)+int(r)) for w,l,r in zip(self.jet,left,right))
        return U,U+F(inc,4*N*unit*S1)/self.L


def uniform(row,bins):
    return dict(row,edges=list(range(0,GRID+1,GRID//bins)))

