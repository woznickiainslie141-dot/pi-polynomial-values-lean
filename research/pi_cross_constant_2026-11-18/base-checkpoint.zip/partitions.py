"""Check every local mesh against the exact within-cell least-squares ranking."""
from fractions import Fraction as F


def ranking(row):
    p=row["density"];full=[r[::-1] for r in p[:0:-1]]+p
    assert all(len(r)==320 for r in full)
    score=[sum((r[2*i]-r[2*i+1])**2 for r in full) for i in range(160)]
    return [score[i]+score[159-i] for i in range(80)]


def check(series,uniform,mode):
    base={r["label"]:r for r in uniform["ordinary"]}
    assert series["unit"]==100000 and series["grid"]==640 and series["mode"]==mode
    expected={"uniform320":320,"local320":320,"local200":200,"local400":400}[mode]
    quantities={}
    for group in ("ordinary","tilted"):
        seen=set()
        for row in series[group]:
            tag=row["label"];assert tag not in seen;seen.add(tag)
            score=ranking(base[tag])
            order=sorted(range(80),key=lambda i:(-score[i],i))
            subdivisions=[2 if mode=="local400" else 1]*160
            if mode=="uniform320":
                subdivisions=[2]*160;use=80
            else:
                use=20 if mode in ("local200","local400") else 32
                for k,i in enumerate(order[:use]):
                    n=4 if mode=="local400" or mode=="local320" and k<24 else 2
                    subdivisions[i]=subdivisions[159-i]=n
            bounds=[0]
            for i,n in enumerate(subdivisions):
                bounds.extend(4*i+j*(4//n) for j in range(1,n+1))
            assert len(bounds)==expected+1 and row["edges"]==bounds
            if group=="ordinary":
                quantities[tag]=str(F(sum(score[i] for i in order[:use]),sum(score))) if sum(score) else "1"
        if group=="ordinary":
            assert seen==set(base)
    return quantities



