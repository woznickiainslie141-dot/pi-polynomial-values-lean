"""Rank, degree and exact prime cost for different even and odd frequency bands."""
from fractions import Fraction as F
from math import floor
from compare import shape_values
from geometry import positive_integral


def parameters(d,design):
    hi,lo,ratios=design["even"],design["odd"],design["a"]
    assert len(hi)==len(lo) and hi[0]==lo[0]==10000 and max(hi[-1],lo[-1])>0
    assert all(type(t) is int and 0<=t<=10000 for t in hi+lo)
    assert all(x>=y for c in (hi,lo) for x,y in zip(c,c[1:]))
    assert all(type(v) is int and v>0 for v in ratios)
    classes=[hi,lo,hi,lo]
    a,L,s,AA,m=shape_values(classes,ratios)
    V=len(ratios)-1
    widths=[F(x+y,20000) for x,y in zip(hi,lo)]
    columns=[(F(w,20000),j) for row in classes for j,w in enumerate(row) if w]
    assert min(a)>=max(w for w,j in columns) and sum(w for w,j in columns)==L
    q=[0]*len(a)
    for r in range(4):
        ids=sorted((i for i in range(len(a)) if (i-V)%4==r),key=lambda i:-a[i])
        for k,i in enumerate(ids):q[i]=k
    cap=(sum(w*j for w,j in columns)-sum(x*h for x,h in zip(a,q)))/L
    def loss(z):
        return -1+(2*sum(min(w,z) for w in widths)+sum(max(0,x-2*z-2*k)
                     for x in a for k in range(1+floor(max(a)/2))))/L
    D=cap-max(loss(z) for z in [F(0),*widths])
    def prime(eta):
        A=max(a);n=max(max(q)+floor(A/eta),max(j+floor(w/eta) for w,j in columns))+1
        area=F(0)
        for h in range(1,n+1):
            parts={}
            for w,j in columns:
                t=(w,max(0,h-j));parts[t]=parts.get(t,0)+1
            for w,j in zip(a,q):
                t=(w,max(0,h-j));parts[t]=parts.get(t,0)-1
            terms=[(w,k,v) for (w,k),v in parts.items() if v]
            breaks=sorted({eta,A,*(w/k for w,k,v in terms if k and eta<w/k<A)})
            tails=[sum(v*max(0,w-k*t) for w,k,v in terms)/L for t in breaks]
            area+=sum(positive_integral(x,y,l,r) for x,y,l,r in zip(breaks,breaks[1:],tails,tails[1:]))
        return A*cap-area
    costs={str(t):prime(t) for t in (F(1,30),F(1,24))}
    return classes,a,L,D,min(costs.values()),dict(rank_gap=str(min(a)-max(w for w,j in columns)),
             degree=str(D),prime_by_cutoff={k:str(v) for k,v in costs.items()},old_cap=str(cap))



