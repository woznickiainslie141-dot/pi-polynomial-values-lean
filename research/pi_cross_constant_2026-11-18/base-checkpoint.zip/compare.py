"""Compare the density partitions with all frequency, angular and price data held fixed."""
import argparse
import json
import sys
from fractions import Fraction as F
from pathlib import Path
from math import ceil, floor

from spatial import HERE,PRIOR,GRID,UNIT,Spatial,read,uniform
from run_certificate import threshold
from geometry import exact_shape,sorted_moments,enc as geom_enc
from angular import integrals
from intervals import log_interval,pi_interval,outward
from prime_windows import verify as all_primes


def signed_upper(coef,lo,hi):
    return coef*(hi if coef>=0 else lo)


def shape_values(classes,raw):
    L=sum(F(x,20000) for widths in classes for x in widths)
    a=[L*w/(2*sum(raw)-raw[0]) for w in raw[:0:-1]+raw]
    s=sum(m*m for m in a)/(2*L)
    A0=sum(m*m*(F(3,2)-log_interval(2*m)[0]) for m in a)/(2*L)
    widths=sorted([F(x,10000) for col in classes for x in col if x],reverse=True)
    # The spectral density and the sorted masses both acquire a factor four in
    # the ordinary interval-cut formula, so divide its output moments by four.
    moments=[v/4 for v in sorted_moments([4*x for x in a],widths)]
    return a,L,s,A0,moments


def sources(d):
    data=read(PRIOR/"reference"/f"case{d}.json")
    f=read(PRIOR/f"spatial{d}.json")
    def convert(rows,bins):
        return [uniform(row,bins) for row in rows]
    return data,dict(ordinary=convert(data["witness"]["knots"],80)+convert(f["ordinary"],160),
                     tilted=convert(f["tilted"],160))


def validated_rows(data,series):
    old={r["label"]:r["field"] for r in data["witness"]["knots"]}
    for key in ("ordinary","tilted"):
        for row in series[key]:
            assert row["label"] in old and row["field"]==old[row["label"]]
            yield key,row


def ingest(calc,data,series,base=None,source="trial"):
    U,P,ids=({}, {}, {}) if base is None else (dict(base[0]),dict(base[1]),dict(base[2]))
    for index,(key,row) in enumerate(validated_rows(data,series)):
        tag=row["label"]
        # All fitted densities are admissible as dual references. Keep the
        # ordinary and tilted pools separate for a matched comparison.
        raw,tilt=calc.bound(row)
        pointer=(source,key,index if key=="ordinary" else index-len(series["ordinary"]))
        if key=="ordinary" and (tag not in U or raw<U[tag]):
            U[tag]=raw;ids[tag,"ordinary"]=pointer
        if tag not in P or tilt<P[tag]:
            P[tag]=tilt;ids[tag,"tilted"]=pointer
    return U,P,ids


def coefficients(d,data,table,spec,L,moments,U,P):
    z=F(str(data["z"])); low_pi,high_pi=pi_interval();grid=table["grid"];unit=table["unit"]
    K={r["label"]:[F(x,UNIT) for x in r["field"]] for r in data["witness"]["knots"]}
    Q=2*sum(i*x for i,x in enumerate(moments,1))/L
    A=F(0);lam=F(0);cost=[F(0)]*len(moments);last=0
    for lo,hi,mix in table["allocation"]:
        assert last==lo<hi<=grid and sum(n for _,n in mix)==unit
        w0,j0=integrals(z,F(lo,grid));w1,j1=integrals(z,F(hi,grid))
        wl,wh=w1[0]-w0[1],w1[1]-w0[0];jl,jh=j1[0]-j0[1],j1[1]-j0[0]
        assert min(wl,jl)>0
        for tag,n in mix:
            assert type(n) is int and n>0
            mult=F(n,unit);k=K[tag];coef=2*sum(x*y for x,y in zip(k[1:],moments))/L
            tilted=P[tag] if tag in spec["price"] else U[tag]
            A+=mult*(signed_upper((U[tag]+tilted)/2,wl,wh)+signed_upper(-coef,jl,jh))
            lam+=mult*wl*F(spec["price"].get(tag,0),2*10**7)
            for i in range(len(moments)):
                cost[i]+=mult*signed_upper(k[i+1]-k[i],jl,jh)
        last=hi
    assert last==grid
    slacks=[low_pi*(1/z-z)/4-y for y in cost];assert min(slacks)>0
    return A+high_pi*(1/z-z)*Q/4,lam,Q,slacks


def evaluate(d,data,table,spec,classes,raw,D,G,computed):
    a,L,s,A0,moments=shape_values(classes,raw);U,P,_=computed
    boundary,lam,Q,slacks=coefficients(d,data,table,spec,L,moments,U,P)
    z=F(str(data["z"]));kl,kh=log_interval(1/z);K=kl*L/2;f0=U["scalar-0"]
    A=d*(A0+G)+(d-1)*f0+kh*s+boundary
    bracket=threshold(D,K,A,lam)
    return dict(threshold=[str(x-1) for x in bracket],D=str(D),G=str(G),K=str(K),A=str(A),Lambda=str(lam),
                L=str(L),s=str(s),A0=str(A0),f0=str(f0),Q=str(Q),z=str(z),
                boundary_with_price=str(boundary),min_direction_slack=str(min(slacks)))


def fixed_b_threshold(rec,b):
    B=b*F(rec["K"]);lam=b*F(rec["Lambda"]);rhs=F(rec["D"])+b*F(rec["A"])
    def margin(C):
        return B-(2*B-C-lam)**2/(8*B)-rhs
    scale=10**10
    lo,hi=ceil(2*B*scale/3),floor((2*B-lam)*scale)
    assert margin(F(lo,scale))<0<margin(F(hi,scale))
    while hi-lo>1:
        k=(lo+hi)//2
        if margin(F(k,scale))>0:hi=k
        else:lo=k
    assert 3*F(lo,scale)+lam>2*B
    return [str(F(x,scale)-1) for x in (lo,hi)]


def prove(d,rec,C,b):
    D,K,A,lam,s,L,Q=(F(rec[k]) for k in ("D","K","A","Lambda","s","L","Q"))
    B=b*K;delta=b*lam
    assert C>d-1 and C+delta<2*B and 3*(C-d+1)+delta>2*B
    h=(d-1)/(b*L);assert 0<h<1 and F(rec["A0"])+F(rec["G"])+F(rec["f0"])>0
    loss=(2*B-C+d-1-delta)/(4*B)
    gamma=F(1,2)-s/L-pi_interval()[1]*Q/(2*L*(1-h*h))
    margin=B-(2*B-C-delta)**2/(8*B)-D-b*A
    assert margin>0 and gamma>loss,(d,float(margin))
    return dict(C=str(C),omega=str(C-1),b=str(b),margin_lower=str(outward(margin,margin,10**13)[0]),
                loss_upper=str(outward(loss,loss,10**11)[1]),secondary_lower=str(outward(gamma,gamma,10**11)[0]))


def old_geometry(d,data,replay=True):
    old=read(PRIOR/"certificate.json")["cases"][d-2]
    sh=exact_shape(d,data["shape"]["u"],data["shape"]["a"])
    pn=read(PRIOR/"prime-certificate.json")[str(d)]
    if replay:
        assert all_primes(data)==pn
    return F(sh["degree_rate_upper"][1]),F(sh["prime_cost_upper"][1])-F(pn["lower"]),old


def compare(d,modes,replay):
    data,old=sources(d)
    table=read(PRIOR/f"angular{d}.json");spec=read(PRIOR/f"center{d}.json")
    classes=[data["shape"]["u"]]*4;raw=data["shape"]["a"]
    a=shape_values(classes,raw)[0];calc=Spatial(d,classes,a,spec["price"])
    D,G,archive=old_geometry(d,data,replay)
    prev=ingest(calc,data,old,source="prior")
    records={"same_mesh_160":evaluate(d,data,table,spec,classes,raw,D,G,prev)}
    uniform_pool=None
    for mode in modes:
        series=read(HERE/f"{mode}-{d}.json")
        if mode=="local400" and uniform_pool is None:
            uniform_pool=ingest(calc,data,read(HERE/f"uniform320-{d}.json"),prev,"uniform320")
        choices=ingest(calc,data,series,uniform_pool if mode=="local400" else prev,mode)
        if mode=="uniform320":uniform_pool=choices
        records[mode]=evaluate(d,data,table,spec,classes,raw,D,G,choices)
        print(d,mode,[float(F(k)) for k in records[mode]["threshold"]],flush=True)
    for rec in records.values():
        rec["fixed_b_threshold"]=fixed_b_threshold(rec,F(archive["b"]))
    return dict(d=d,checkpoint=archive["omega"],fixed_b=archive["b"],previous_directed_threshold=archive["threshold_after_center"],
                stages=records)


if __name__=="__main__":
    if not __debug__: raise RuntimeError("Enable Python assertions.")
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--modes",nargs="+",default=["uniform320","local200","local320","local400"])
    arg.add_argument("--json",type=Path)
    args=arg.parse_args()
    out=[compare(d,args.modes,True) for d in (2,3)]
    if args.json: args.json.write_text(json.dumps(dict(status="passed",cases=out),indent=2)+"\n",encoding="utf-8")





