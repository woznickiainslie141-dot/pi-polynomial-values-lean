"""Standalone final endpoint replay. Run with python -I -S -B independent.py."""
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from scalar import Scalar,PRIOR,F,read
from poisson_fourier import pi_interval,log_interval,integrals
from math import floor
import argparse,json


def prime_factorial(a,b,q,j,L,eta):
    def factorial(widths):
        return sum((w-k*eta)**2/(2*k) for w in widths for k in range(1,floor(w/eta)+1))
    cap=(sum(w*g for w,g in zip(b,j))-sum(w*g for w,g in zip(a,q)))/L
    value=eta*cap+(factorial(a)-factorial(b))/L
    stop=max(max(a),max(b))
    highest=max(max(q)+floor(max(a)/eta),max(j)+floor(max(b)/eta))
    for h in range(1,highest+1):
        terms=[(w,max(0,h-g),1) for w,g in zip(a,q)]+[(w,max(0,h-g),-1) for w,g in zip(b,j)]
        xs=sorted({eta,stop,*(w/k for w,k,sign in terms if k and eta<w/k<stop)})
        ys=[sum(sign*max(0,w-k*x) for w,k,sign in terms)/L for x in xs]
        for l,r,p,t in zip(xs,xs[1:],ys,ys[1:]):
            if min(p,t)>=0:value-=(r-l)*(p+t)/2
            elif max(p,t)>0:value-=(r-l)*max(p,t)**2/(2*abs(p-t))
    return value


def geometry(d,design):
    h,l,rat=design["even"],design["odd"],design["a"]
    assert len(h)==len(l) and h[0]==l[0]==10000
    assert all(isinstance(v,int) and 0<=v<=10000 for v in h+l)
    assert all(y<=x for s in (h,l) for x,y in zip(s,s[1:])) and all(x>0 for x in rat)
    classes=[h,l,h,l];u=[F(x+y,20000) for x,y in zip(h,l)]
    L=2*sum(u);a=[L*r/(2*sum(rat)-rat[0]) for r in rat[:0:-1]+rat]
    cols=[(F(w,20000),j) for layer in classes for j,w in enumerate(layer) if w]
    assert sum(x for x,j in cols)==sum(a)==L and min(a)>=max(w for w,j in cols)
    V=len(rat)-1;q=[0]*len(a)
    for r in range(4):
        ids=[i for i in range(len(a)) if (i-V)%4==r]
        for g,i in enumerate(sorted(ids,key=lambda i:-a[i])):q[i]=g
    cap=(sum(w*j for w,j in cols)-sum(x*g for x,g in zip(a,q)))/L
    collection=[]
    for z in [F(0),*u]:
        k=0;rest=F(0)
        while max(a)>2*(z+k):
            rest+=sum(max(0,x-2*(z+k)) for x in a);k+=1
        collection.append(-1+(2*sum(min(w,z) for w in u)+rest)/L)
    D=cap-max(collection)
    from lift_sums import prime_saving
    b,j=zip(*cols)
    G=min(prime_factorial(a,b,q,j,L,eta) for eta in (F(1,24),F(1,30)))-prime_saving(d,classes,a)
    # Compute quantile moments from direct right-tail integrals at each row boundary.
    ws=sorted([F(w,10000) for s in classes for w in s if w],reverse=True)
    moments=[];last=F(0)
    for i in range(V,0,-1):
        wanted=sum(a[V+i:])
        for k in range(1,len(ws)+1):
            x=(sum(ws[:k])-4*wanted)/k
            if (ws[k] if k<len(ws) else 0)<=x<=ws[k-1]:break
        assert sum(max(0,w-x) for w in ws)==4*wanted
        area=sum(max(0,w*w-x*x) for w in ws)/8
        moments.append(area-last);last=area
    return classes,a,D,G,moments[::-1]


def check(d,design,pool,geo,pure,tilt):
    classes,a,D,G,mom=geo;L=sum(a);s=sum(w*w for w in a)/(2*L)
    A0=sum(w*w*(F(3,2)-log_interval(2*w)[0]) for w in a)/(2*L)
    spec=read(PRIOR/f"center{d}.json");tab=read(HERE/f"angles{d}.json")
    data=read(PRIOR/"reference"/f"case{d}.json");z=F(design["z"])
    weights={r["label"]:r["field"] for r in data["witness"]["knots"]}
    for tag,row in pool["ordinary"].items():
        if tag not in weights:
            assert tag.startswith("mid-") and len(row["field"])==len(a)//2+1 and row["field"][0]==0
            assert all(type(v) is int and abs(v)<10**8 for v in row["field"])
            weights[tag]=row["field"]
    for tag,row in pool["ordinary"].items():
        assert row["label"]==tag and row["field"]==weights[tag]
        assert tag in pure
    for tag,row in pool["tilted"].items():
        assert tag in spec["price"] and row["label"]==tag and row["field"]==weights[tag]
        assert tag in tilt
    Q=2*sum(i*v for i,v in enumerate(mom,1))/L
    cutoff=(1/z-z)/4;plo,phi=pi_interval();W=phi*cutoff*Q;Lam=F(0);spend=[F(0)]*len(mom)
    end=0
    for lo,hi,mix in tab["allocation"]:
        assert lo==end<hi<=tab["grid"];end=hi
        assert sum(n for _,n in mix)==tab["unit"]
        w0,j0=integrals(z,F(lo,tab["grid"]));w1,j1=integrals(z,F(hi,tab["grid"]))
        wl,wh=w1[0]-w0[1],w1[1]-w0[0];jl,jh=j1[0]-j0[1],j1[1]-j0[0]
        assert min(wl,jl)>0
        def upper(t,x,y):return max(t*x,t*y)
        for tag,n in mix:
            assert type(n) is int and n>0
            k=[F(t,100000) for t in weights[tag]];r=F(n,tab["unit"])
            w=(pure[tag]+(tilt[tag] if tag in spec["price"] else pure[tag]))/2
            W+=r*(upper(w,wl,wh)+upper(-2*sum(v*x for v,x in zip(k[1:],mom))/L,jl,jh))
            Lam+=r*wl*F(spec["price"].get(tag,0),2*10**7)
            for i in range(len(spend)):spend[i]+=r*upper(k[i+1]-k[i],jl,jh)
    assert end==tab["grid"] and min(plo*cutoff-e for e in spend)>0
    C,b=F(design["C"]),F(design["b"]);kl,kh=log_interval(1/z);B=b*kl*L/2
    f0=pure["scalar-0"];assert A0+G+f0>0
    def minimum(c):
        offsets=[F(0)]+[n*c+b*Lam for n in range(1,len(classes[0]))]
        for j in range(1,len(offsets)+1):
            level=(2*B+sum(offsets[:j]))/j
            if j==len(offsets) or level<=offsets[j]:
                p=[(level-x)/(2*B) for x in offsets[:j]]
                assert min(p)>=0 and sum(p)==1
                return sum(x*v+B*v*v for x,v in zip(offsets,p)),sum(i*v for i,v in enumerate(p))
        raise AssertionError("No valid active simplex face")
    h=(d-1)/(b*L);assert 0<h<1
    lhs,share=minimum(C);_,loss=minimum(C-d+1)
    gamma=F(1,2)-s/L-phi*Q/(2*L*(1-h*h))
    margin=lhs-D-b*(d*(A0+G)+(d-1)*f0+kh*s+W)
    assert gamma>loss and margin>0,(d,float(margin))
    down=lambda x: str(F(floor(x*10**13),10**13))
    return dict(d=d,omega=str(C-1),margin_lower=down(margin),secondary_minus_loss_lower=down(gamma-loss),
                degree=str(D),prime=str(G),b=str(b),critical_share_lower=down(share))


def main():
    if not __debug__:raise RuntimeError("Enable Python assertions.")
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--json",type=Path);args=parser.parse_args()
    out=[]
    for d in (2,3):
        names=["parity","balanced"]
        designs=[read(HERE/f"{key}{d}.json") for key in ("design","balanced")]
        pool=read(HERE/f"final-fields{d}.json");fees=read(PRIOR/f"center{d}.json")["price"]
        geos=[geometry(d,design) for design in designs]
        models=[Scalar(d,g[0],g[1]) for g in geos];tables=[]
        for key in ("ordinary","tilted"):
            tab=[{},{}]
            for tag,row in pool[key].items():
                vals=models[0].bounds(row,fees[tag] if key=="tilted" else 0,models[1:])
                for t,v in zip(tab,vals):t[tag]=v
            tables.append(tab)
        records={}
        for i,key in enumerate(names):
            rec=check(d,designs[i],pool,geos[i],tables[0][i],tables[1][i])
            records[key]=rec;print(d,key,"w",rec["omega"],"margin >=",rec["margin_lower"],flush=True)
        out.append(dict(d=d,**records))
    if args.json:args.json.write_text(json.dumps(dict(status="passed",cases=out),indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":main()





