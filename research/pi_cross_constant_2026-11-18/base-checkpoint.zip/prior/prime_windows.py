"""Two-sided bounds for the total gain of the residue estimate over all prime scales."""

import argparse
import json
import sys
from fractions import Fraction as F
from math import floor
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference"))
from residue import balanced_excess, check_old_cap

ROUND = 10**20


def shape(data):
    widths = [F(t, 10000) for t in data["shape"]["u"]]
    half = data["shape"]["a"]
    ratios = half[:0:-1] + half
    L = 2*sum(widths)
    masses = [L*r/sum(ratios) for r in ratios]
    V = len(half)-1
    ranks = [0]*len(ratios)
    for group in range(4):
        ids = [i for i in range(len(ratios)) if (i-V)%4 == group]
        for rank, i in enumerate(sorted(ids,key=lambda i: -masses[i])):
            ranks[i] = rank
    return widths, masses, ranks


def phi(s, M):
    quotient, remainder = np.divmod(s, M)
    return M*quotient*(quotient-1)//2 + quotient*remainder


def jet_counts(indices, U, masses, mesh):
    den = 10000*mesh
    numerators = indices[:, None]*U
    bands, frac = np.divmod(numerators, den)
    count = (2*bands+(frac != 0)).sum(axis=1)
    events = np.minimum(frac, den-frac)
    jumps = np.where((events == 0) | (2*events == den), 0,
                     np.where(2*frac < den, -1, 1))
    row = sum(indices*a.numerator//(mesh*a.denominator) for a in masses)
    return count, events, jumps, row


def tau_bounds(first, last, M, den):
    c0, e0, j0, h0 = first
    c1, e1, j1, h1 = last
    events = np.column_stack((e0,e1))
    seq = np.argsort(events, axis=1, kind="stable")
    events = np.take_along_axis(events, seq, axis=1)
    zero = np.zeros_like(j0)
    inc0 = np.take_along_axis(np.column_stack((j0,zero)), seq, axis=1)
    inc1 = np.take_along_axis(np.column_stack((zero,j1)), seq, axis=1)
    lower = (c0-h1)[:,None] + np.cumsum(inc0,axis=1)
    upper = (c1-h0)[:,None] + np.cumsum(inc1,axis=1)
    lower = np.column_stack((c0-h1, lower))
    upper = np.column_stack((c1-h0, upper))
    lens = np.diff(events,axis=1,prepend=0,append=den//2)
    assert np.all((lens == 0) | (lower <= upper))
    # All arrays in the arithmetic below contain small bounded integers.
    assert max(int(np.abs(lower).max()),int(np.abs(upper).max())) <= 4*(M+j0.shape[1])
    left, right = phi(lower,M), phi(upper,M)
    low = np.where(upper < 0,right,np.where(lower > M,left,0))
    high = np.maximum(left,right)
    assert int(lens.max())*int(high.max())*lens.shape[1] < 2**62
    return (lens*low).sum(axis=1), (lens*high).sum(axis=1)


def inner_part(U, masses, start, stop, mesh):
    den = 10000*mesh
    L = sum(masses)
    nmax = mesh*stop
    assert max(nmax*max(map(int,U)), *(nmax*a.numerator for a in masses),
               *(mesh*a.denominator for a in masses)) < 2**61
    assert nmax*max(map(int,U))*len(U) < 2**61
    low, high = 0, 0
    factor = ROUND*mesh**2*L.denominator
    normal = den*L.numerator
    for base in range(mesh*start,nmax,1024):
        idx = np.arange(base,min(nmax,base+1024),dtype=np.int64)
        lo, hi = tau_bounds(jet_counts(idx,U,masses,mesh),jet_counts(idx+1,U,masses,mesh),
                            len(masses),den)
        for j in np.flatnonzero(hi):
            i = int(idx[j])
            divisor = normal*(i*(i+1))**2
            scale = factor*(2*i+1)
            low += int(lo[j])*scale//divisor
            high += (int(hi[j])*scale+divisor-1)//divisor
    return F(low,ROUND), F(high,ROUND)


def raw(y, widths, masses):
    H = sum(floor(a/y) for a in masses)
    count = 0
    jumps = {}
    for u in widths:
        x = u/y
        k = floor(x)
        f = x-k
        count += 2*k + int(f != 0)
        for t, delta in ((f,-1),(1-f,1)):
            if 0 < t < F(1,2):
                jumps[t] = jumps.get(t,0)+delta
    last = F(0)
    total = F(0)
    for t in sorted({*jumps,F(1,2)}):
        total += (t-last)*balanced_excess(count-H,len(masses))
        count += jumps.get(t,0)
        last = t
    return 2*y*total/sum(masses)


def positive_integral(width, a, b):
    if max(a,b) <= 0:
        return F(0)
    if min(a,b) >= 0:
        return width*(a+b)/2
    return width*max(a,b)**2/(2*abs(a-b))


def outer_part(widths, masses, ranks, lo):
    L = sum(masses)
    hi = max(masses)
    cap = (2*sum(j*u for j,u in enumerate(widths))-sum(q*a for q,a in zip(ranks,masses)))/L
    cols = [u/2 for u in widths]
    grades = list(range(len(cols)))
    critical = {lo,hi}
    slopes = set(masses+cols+[2*u for u in widths])
    for i,u in enumerate(widths):
        for v in widths[:i]:
            slopes.update((u+v,abs(u-v)))
    for length in slopes:
        for k in range(1,floor(length/lo)+1):
            if lo < length/k < hi:
                critical.add(length/k)
    jobs = []
    max_h = max(max(ranks)+floor(hi/lo),max(grades)+floor(max(cols)/lo))+1
    for h in range(1,max_h+1):
        terms = [(4,b,max(0,h-j)) for j,b in enumerate(cols)]
        terms += [(-1,a,max(0,h-q)) for q,a in zip(ranks,masses)]
        cuts = sorted({lo, hi, *(a/k for _,a,k in terms if k and lo<a/k<hi)})
        def diff(y):
            return sum(mult*max(0,a-k*y) for mult,a,k in terms)
        vals = [diff(y) for y in cuts]
        if max(vals) <= 0:
            continue
        jobs.append(terms)
        for a,b,v,w in zip(cuts,cuts[1:],vals,vals[1:]):
            if v*w < 0:
                critical.add((a*w-b*v)/(w-v))
        critical.update(cuts)
    def old_discount(y):
        return sum(max(0,sum(mult*max(0,a-k*y) for mult,a,k in terms)) for terms in jobs)/L
    total = F(0)
    cuts = sorted(critical)
    for l,r in zip(cuts,cuts[1:]):
        # Interior evaluations recover one-sided limits even at a jump of H.
        u,v = (2*l+r)/3,(l+2*r)/3
        a,b = raw(u,widths,masses),raw(v,widths,masses)
        x,w = 2*a-b,2*b-a
        ol,orr = old_discount(l),old_discount(r)
        assert min(x,w,ol,orr) >= 0 and max(ol,orr) <= cap
        # min(cap,S)-O after taking the positive part equals (S-O)+ -(S-cap)+.
        total += positive_integral(r-l,x-ol,w-orr)-positive_integral(r-l,x-cap,w-cap)
    return total, len(cuts)-1


def verify(data, grid=None):
    widths,masses,ranks = shape(data)
    L = sum(masses)
    U = np.asarray(data["shape"]["u"],dtype=np.int64)
    first = 5 if data["d"] == 2 else 8
    cap = (2*sum(i*u for i,u in enumerate(widths))-sum(q*a for q,a in zip(ranks,masses)))/L
    check_old_cap(widths,masses,ranks,F(1,30),F(1,first))
    max_phi = balanced_excess(-len(U),len(masses))
    assert cap > F(max_phi,first)/L
    grid = grid or [(first,40,4096),(40,128,1024),(128,512,256),(512,2048,64),(2048,8192,16)]
    assert grid[0][0] == first and all(a[1] == b[0] for a,b in zip(grid,grid[1:]))
    boxes = []
    outer, strips = outer_part(widths,masses,ranks,F(1,first))
    lower, upper = outer, outer
    for l,r,m in grid:
        a,b = inner_part(U,masses,l,r,m)
        lower += a
        upper += b
        boxes.append(dict(t=[l,r],mesh=m,lower=str(a),upper=str(b)))
    tail = F(max_phi,2*grid[-1][1]**2)/L
    return dict(lower=str(lower),upper=str(upper+tail),tail_upper=str(tail),
                outer_exact=str(outer),outer_strips=strips,inner=boxes)


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Enable Python assertions.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json",type=Path)
    args = parser.parse_args()
    out={}
    for d in (2,3):
        data=json.loads((HERE/"reference"/f"case{d}.json").read_text(encoding="utf-8"))
        out[str(d)]=verify(data)
        print(d,*(f"{float(F(out[str(d)][k])):.12g}" for k in ("lower","upper","outer_exact")),flush=True)
    if args.json:
        args.json.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
