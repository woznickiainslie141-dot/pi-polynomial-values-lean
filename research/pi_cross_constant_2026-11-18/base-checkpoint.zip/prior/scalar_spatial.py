"""Second spatial proof using Python integers, packed convolutions, and density jumps."""
from fractions import Fraction as F
from functools import lru_cache

import struct

N=10000
U1=10**9
U2=10**12
WORD=64


@lru_cache(None)
def primitives():
    # Telescoping integer logarithms. Keep error bounds on each increment.
    precision=10**23
    logs=[(0,0),(0,0)]
    for i in range(1,2*N):
        base=2*i+1
        den=base
        power=1
        lo,hi=logs[-1]
        while True:
            val=2*precision//(power*den)
            if val==0:
                break
            lo+=val
            hi+=val+1
            den*=base**2
            power+=2
        logs.append((lo,hi+2))
    first=[0]; second=[0]
    for i in range(1,2*N+1):
        low=logs[i][0]+logs[2][0]-logs[N][1]
        high=logs[i][1]+logs[2][1]-logs[N][0]
        f=i*U1*(low-precision)//(N*precision)
        g=i*i*U2*(2*low-3*precision)//(4*N*N*precision)
        assert (f+2)*N*precision >= i*U1*(high-precision)
        assert (g+2)*4*N*N*precision >= i*i*U2*(2*high-3*precision)
        first.append(f);second.append(g)
    return [-x for x in reversed(first[1:])]+first,second


def changes(rho):
    return tuple(y-x for x,y in zip((0,*rho),(*rho,0)))


@lru_cache(None)
def packs(bins):
    # Uniform bin edges split each convolution into short arithmetic progressions.
    one,_=primitives()
    assert 2*N%bins==0
    step=2*N//bins
    assert N%step==0
    shift=max(map(abs,one))
    blocks=[]
    for r in range(step):
        vals=[x+shift for x in one[r::step]]
        p=int.from_bytes(struct.pack("<"+"Q"*len(vals),*vals),"little")
        size=len(vals)+bins
        bias=((1<<(WORD*size))-1)//((1<<WORD)-1)*(1<<(WORD-1))
        blocks.append((p,bias))
    return blocks,shift


def potentials(jumps):
    # Digit multiplication forms the linear convolution. Bias every output digit
    # before extracting it, so signed coefficients cannot borrow into neighbours.
    bins=len(jumps)-1
    step=2*N//bins
    blocks,shift=packs(bins)
    assert 2*shift*sum(map(abs,jumps)) < 1<<(WORD-1) and sum(jumps)==0
    poly=sum(x<<(WORD*i) for i,x in enumerate(jumps))
    out=[0]*(N+1)
    for r,(p,bias) in enumerate(blocks):
        n=(N-r)//step+1
        folded=((p*poly+bias)>>(WORD*(3*N//step)))% (1<<(WORD*n))
        values=struct.unpack("<"+"Q"*n,folded.to_bytes(8*n,"little"))
        out[r::step]=[x-(1<<(WORD-1)) for x in values]
    return out


def kernel_sum(seams,jumps):
    """Sum of jump products times the even second primitive, by integration by parts."""
    second=primitives()[1]
    active=[(x,v) for x,v in zip(seams,jumps) if v]
    return 2*sum(q*b*second[y-x] for i,(y,b) in enumerate(active) for x,q in active[:i])


def full(data,row,bins):
    widths=data["shape"]["u"]
    ratios=data["shape"]["a"]
    L=F(2*sum(widths),N)
    a=[L*r/(2*sum(ratios)-ratios[0]) for r in ratios[:0:-1]+ratios]
    unit=data["witness"]["unit"]
    k=row["field"];k=[-v for v in k[:0:-1]]+k
    beta=row["b"][:0:-1]+row["b"]
    pos=row["density"];rho=[r[::-1] for r in pos[:0:-1]]+pos
    assert len(rho)==len(k)==len(beta)==len(a) and all(len(r)==bins for r in rho)
    assert all(type(v) is int for v in [*k,*beta,*(v for rr in rho for v in rr)])
    assert pos[0]==pos[0][::-1] and k[len(k)//2]==0
    edges=list(range(-N,N+1,2*N//bins))
    jumps=[changes(r) for r in rho]
    fields=[];squares=0
    for dr,slope,price in zip(jumps,k,beta):
        norm=sum(map(abs,dr))
        potential=potentials(dr)
        offset=-U1*price+2*norm
        fields.append([v+offset+x*(U1//N)*slope for x,v in enumerate(potential)])
        # -I equals the positive-sign jump sum. Each primitive has error <= 2.
        squares+=kernel_sum(edges,dr)+2*norm**2
    m=len(a)
    joins=sorted(set(edges+widths+[-v for v in widths]))
    density_sums=list(map(sum,zip(*rho)))
    step=2*N//bins
    residual=[unit*sum(abs(l+r)<2*u for u in widths)-density_sums[(l+N)//step]
              for l,r in zip(joins,joins[1:])]
    dr=changes(residual)
    residual_upper=F(-kernel_sum(joins,dr)+2*sum(map(abs,dr))**2,U2*unit**2)
    corrected=min(0,residual_upper)/(2*m*L)
    error=(F(len(widths)*sum(map(max,zip(*(map(abs,d) for d in jumps)))),unit)
           *F(5+(2*N).bit_length(),4*N*N))
    constant=(error+F(squares,2*U2*unit**2)+sum(v*b for v,b in zip(a,beta))/unit)/L+corrected
    return fields,constant


@lru_cache(None)
def cell_weights(widths):
    return tuple(sum(i<=u for u in widths) for i in range(1,N+1))


def upper(data,row,bins,anchor=None,price=0):
    values,constant=full(data,row,bins)
    weights=cell_weights(tuple(data["shape"]["u"]))
    env=list(map(max,zip(*values)))
    num=sum(m*(l+r) for m,l,r in zip(weights,env,env[1:]))
    unit=U1*data["witness"]["unit"]
    L=F(2*sum(data["shape"]["u"]),N)
    if price:
        assert unit%10**7==0 and len(anchor)==N
        cost=price*(unit//10**7)
        # Form the modified maxima directly at both ends of each individual cell.
        for i,(m,a) in enumerate(zip(weights,anchor)):
            if m==1:
                continue
            left=max(v[i]+(cost if a!=n else 0) for n,v in enumerate(values))
            right=max(v[i+1]+(cost if a!=n else 0) for n,v in enumerate(values))
            num+=(m-1)*(left+right-env[i]-env[i+1])
    return constant+F(num,N*unit)/L


def all_bounds(data,fine,spec):
    baseline={r["label"]:r for r in data["witness"]["knots"]}
    ordinary={r["label"]:r for r in fine["ordinary"]}
    tilted={r["label"]:r for r in fine["tilted"]}
    replacements={r["label"]:r for r in spec.get("knots",[])}
    price=spec["price"];assert set(ordinary)==set(baseline) and fine["unit"]==data["witness"]["unit"]
    tag=spec["anchor"];bins=spec.get("anchor_bins",data["witness"]["bins"])
    rows=ordinary if bins==fine["bins"] else baseline
    vals,_=full(data,rows[tag],bins)
    anchor=[max(range(len(vals)),key=lambda n: vals[n][i]+vals[n][i+1]) for i in range(N)]
    raw={};penalized={}
    for tag,row in baseline.items():
        assert row["field"]==ordinary[tag]["field"]
        raw[tag]=min(upper(data,row,80),upper(data,ordinary[tag],fine["bins"]))
        if tag not in price:
            penalized[tag]=raw[tag]
            continue
        assert type(price[tag]) is int and price[tag]>0
        choices=[(replacements.get(tag,row),80),(ordinary[tag],fine["bins"])]
        if tag in tilted:
            choices.append((tilted[tag],fine["bins"]))
        assert all(r["field"]==row["field"] for r,_ in choices)
        penalized[tag]=min(upper(data,r,b,anchor,price[tag]) for r,b in choices)
    return raw,penalized


