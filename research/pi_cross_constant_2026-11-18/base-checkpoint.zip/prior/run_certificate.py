"""Replay the polynomial-value endpoints from the integer witnesses and prime enclosures."""
import argparse
import importlib.util
import json
import sys
from fractions import Fraction as F
from math import ceil, floor
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"reference"))
from prime_windows import verify as prime_check, shape
from center import anchored_bounds
from energy_remainder import savings as reference_savings
from energy import fields, primitives
from geometry import exact_shape, sorted_moments
from intervals import log_interval, outward, pi_interval

loader = importlib.util.spec_from_file_location("incumbent_verifier",HERE/"reference"/"verify.py")
previous = importlib.util.module_from_spec(loader)
loader.loader.exec_module(previous)


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def enc(lo, hi=None, scale=10**12):
    return [str(x) for x in outward(lo,lo if hi is None else hi,scale)]


def threshold(D,K,A,lam=F(0)):
    """Infimum for the fixed directed primary-root criterion, optimizing positive b."""
    def test(t):
        p = D/t
        return K*((1-p)**2+p*p)+lam*p-A
    scale = 10**9
    low,high = ceil(3*D*scale),ceil(6*D*scale)
    while test(F(high,scale)) <= 0:
        high *= 2
    assert test(F(low,scale)) < 0 and lam < 2*K/3
    while high-low>1:
        middle=(low+high)//2
        if test(F(middle,scale))>0:
            high=middle
        else:
            low=middle
    assert 2*K*(1-3*D/F(low,scale)) > lam
    return F(low,scale),F(high,scale)


def test_fine(data, fine):
    assert fine["unit"]==data["witness"]["unit"] and fine["bins"]==160
    old={r["label"]:r for r in data["witness"]["knots"]}
    for key in ("ordinary","tilted"):
        tags=set()
        for r in fine[key]:
            name=r["label"]
            assert name in old and name not in tags and r["field"]==old[name]["field"]
            tags.add(name)
            assert len(r["b"])==len(old[name]["b"])==len(r["density"])
            assert all(len(x)==fine["bins"] for x in r["density"])
            for line in [r["b"],*r["density"]]:
                assert all(type(v) is int and abs(v)<10**8 for v in line)
        if key=="ordinary":
            assert tags==set(old)


def new_fields(data, meshes, sh, fine):
    test_fine(data,fine)
    nodes=fields(sh,data["witness"],*meshes)
    rem=reference_savings(data,meshes[1])
    coarse={r["label"]:F(r["upper"])-rem[r["label"]] for r in nodes}
    witness=dict(bins=fine["bins"],unit=fine["unit"],knots=fine["ordinary"])
    rows=fields(sh,witness,*meshes)
    fine_rem=reference_savings(dict(data,witness=witness),meshes[1])
    pure={r["label"]:min(coarse[r["label"]],F(r["upper"])-fine_rem[r["label"]]) for r in rows}
    return nodes,coarse,pure


def angular_case(data,table):
    assert set(table)=={"allocation","grid","unit"}
    return dict(data,**table)


def relevant(data, rows):
    tags={tag for _,_,mix in data["allocation"] for tag,_ in mix}|{"scalar-0"}
    return [r for r in rows if r["label"] in tags]


def inputs(data, meshes, prime, spec, fine, table):
    u,a,_ = shape(data)
    L=sum(a)
    d=data["d"]
    sh=exact_shape(d,data["shape"]["u"],data["shape"]["a"])
    moments=sorted_moments(a,u)
    Q=2*sum(i*m for i,m in enumerate(moments,1))/L
    incumbent=previous.check(data,meshes)
    old_saving=F(incumbent["prime_saving"])
    old_C=F(incumbent["C"])
    assert old_C-1=={2:F("16.17137"),3:F("27.417936")}[d]
    nodes,coarse,ordinary=new_fields(data,meshes,sh,fine)
    reduced=[dict(row,upper=str(ordinary[row["label"]])) for row in nodes]
    coarse_rows=[dict(row,upper=str(coarse[row["label"]])) for row in nodes]
    angular=angular_case(data,table)
    boundary,f0,slacks=previous.angular_upper(angular,relevant(angular,reduced),moments,L,Q)
    boundary_old_grid,_,_=previous.angular_upper(data,reduced,moments,L,Q)
    boundary_coarse,f0_coarse,_=previous.angular_upper(data,coarse_rows,moments,L,Q)
    boundary0,f00,_=previous.angular_upper(data,nodes,moments,L,Q)
    lam,delta,rows=anchored_bounds(angular,meshes,sh,ordinary,spec,fine)
    G0=F(incumbent["G_before"])
    low,high=F(prime["lower"]),F(prime["upper"])
    assert high>=low>old_saving>0
    A0,D,s = (F(incumbent[key]) for key in ("A0_upper","D_upper","s"))
    z=F(str(data["z"]))
    kl,kh=log_interval(1/z)
    K=kl*L/2
    def bare(g,bdry,f):
        return d*(A0+g)+(d-1)*f+s*kh+bdry
    before=threshold(D,K,bare(G0-old_saving,boundary0,f00))
    prime_range=(threshold(D,K,bare(G0-high,boundary0,f00))[0],
                 threshold(D,K,bare(G0-low,boundary0,f00))[1])
    G=G0-low
    ordinary_A=bare(G,boundary,f0)
    base=threshold(D,K,ordinary_A)
    A=ordinary_A+delta
    t=threshold(D,K,A,lam)
    target_share=F("0.1858") if d==2 else F("0.1980")
    lower_share,upper_share=((F(".18"),F(".19")) if d==2 else (F(".19"),F(".20")))
    assert lam>0 and lam*lower_share-delta>0
    assert t[1]<base[0]<prime_range[1]<before[0]<old_C
    result=dict(d=d,prior_C=str(old_C),old_window_saving=str(old_saving),
                total_saving=[str(low),str(high)],extra_saving=enc(low-old_saving,high-old_saving),
                frozen_old_threshold=list(map(str,before)),frozen_prime_threshold=list(map(str,prime_range)),
                previous_endpoint_minus_prime_threshold=enc(old_C-prime_range[1],old_C-prime_range[0]),
                frozen_old_threshold_minus_prime_threshold=enc(before[0]-prime_range[1],before[1]-prime_range[0]),
                threshold_after_energy=list(map(str,base)),threshold_after_center=list(map(str,t)),
                common_residual_decrease=enc(bare(G,boundary0,f00)-bare(G,boundary_coarse,f0_coarse)),
                finer_spatial_decrease=enc(bare(G,boundary_coarse,f0_coarse)-bare(G,boundary_old_grid,f0)),
                angular_refit_decrease=enc(boundary_old_grid-boundary),
                energy_decrease=enc(bare(G,boundary0,f00)-ordinary_A),
                new_angle_pieces=len(table["allocation"]),new_angle_grid=table["grid"],
                near_share=str(target_share),boundary_decrease_at_share=enc(lam*target_share-delta),
                share_interval=list(map(str,(lower_share,upper_share))),
                boundary_decrease_over_interval=enc(lam*lower_share-delta,lam*upper_share-delta),
                L=str(L),Q=str(Q),s=str(s),z=str(z),D_upper=str(D),A0_upper=str(A0),
                G_before=str(G0),G_upper=str(G),f0_upper=str(f0),boundary_upper=str(boundary),
                kappa=list(map(str,(kl,kh))),lambda_lower=str(lam),delta_upper=str(delta),
                angular_slacks=[enc(x)[0] for x in slacks],rows=rows,
                rank_before_T=sh["min_rank_slack_before_T"],rank_at_T=sh["rank_slack_at_T"])
    return result,(D,K,A,lam,s,Q,L,G,A0,f0)


def finish(report,numbers,C,b):
    D,K,A,lam,s,Q,L,G,A0,f0 = numbers
    d=report["d"]
    B=b*K
    delta=b*lam
    assert 0 < C-d+1 < C and C+delta<2*B and 3*(C-d+1)+delta>2*B
    h=(d-1)/(b*L)
    assert 0<h<1 and A0+G+f0>0 and F(report["threshold_after_center"][1])<C
    primary=B-(2*B-C-delta)**2/(8*B)
    rhs=D+b*A
    share=(2*B-C-delta)/(4*B)
    assert primary==(C+delta)*share+B*((1-share)**2+share*share)
    loss=(2*B-C+d-1-delta)/(4*B)
    secondary=F(1,2)-s/L-pi_interval()[1]*Q/(2*L*(1-h*h))
    assert primary>rhs and secondary>loss
    report.update(C=str(C),omega=str(C-1),b=str(b),primary_lower=enc(primary)[0],
                  rhs_upper=enc(rhs)[1],margin=enc(primary-rhs),critical_share=enc(share),
                  secondary_lower=enc(secondary)[0],loss_upper=enc(loss)[1],
                  exponent_gain=str(F(report["prior_C"])-C))
    return report


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions.")
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json",type=Path)
    args=parser.parse_args()
    meshes=primitives()
    expected=read(HERE/"prime-certificate.json")
    targets=read(HERE/"targets.json")
    report=[]
    for d in (2,3):
        data=read(HERE/"reference"/f"case{d}.json")
        prime=prime_check(data)
        assert prime==expected[str(d)]
        rec,values=inputs(data,meshes,prime,read(HERE/f"center{d}.json"),
                         read(HERE/f"spatial{d}.json"),read(HERE/f"angular{d}.json"))
        row=finish(rec,values,F(targets[str(d)]["C"]),F(targets[str(d)]["b"]))
        report.append(row)
        print(f"d={d} omega={row['omega']} margin>={row['margin'][0]}",flush=True)
    if args.json:
        args.json.write_text(json.dumps(dict(status="passed",cases=report),indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()




