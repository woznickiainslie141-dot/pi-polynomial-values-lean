# Lower bounds for quadratic and cubic polynomial values at $\pi$

**Abstract.** Let $H(P)$ be the largest absolute coefficient of a nonzero integer polynomial. For $\deg P\le d$ we prove $|P(\pi)|\ge c_d H(P)^{-w_d}$, with $w_2=16.1942$ and $w_3=27.4188$. The constants $c_d>0$ are independent of $P$. A nonvanishing interpolation determinant supplies one Gaussian-integer resultant. Separate analytic paths for its rows bound the contribution of a root near $\pi$, while estimates at the other conjugates recover the polynomial-value exponent. The numerical margins are certified by finite rational inequalities. A separate rectangular construction gives an asymptotic coefficient $8.32$ for sufficiently large degrees.

**Keywords.** Transcendence measure, interpolation determinant, resultant, logarithmic energy, approximation of $\pi$.

## 1. Statement and relation to earlier work

Write $\mathcal L(P)=\sum_j |p_j|$ and $H(P)=\max_j |p_j|$ for $P(Y)=\sum_j p_jY^j$. We use natural logarithms. Define $\omega_d(\xi)$ as the supremum of the real $w$ for which $0<|P(\xi)|<H(P)^{-w}$ for infinitely many distinct nonzero $P\in\mathbb Z[Y]$ of degree at most $d$. Only finitely many such polynomials have bounded height.

**Theorem 1.** For each $d\in\{2,3\}$ there exists $c_d>0$ such that, for every nonzero $P\in\mathbb Z[Y]$ with $\deg P\le d$,

$$
 |P(\pi)|\ \ge\ c_d H(P)^{-w_d},\qquad
 w_2=\frac{80971}{5000}=16.1942,\quad
 w_3=\frac{68547}{2500}=27.4188.                                      \tag{1}
$$

Consequently $\omega_2(\pi)\le16.1942$ and $\omega_3(\pi)\le27.4188$. Indeed, for $w>w_d$, $c_dH^{-w_d}>H^{-w}$ for all sufficiently large $H$. The endpoint in (1) itself holds without an additional $\varepsilon$. This includes nonprimitive and reducible polynomials, repeated factors and constants. The proof gives existence of $c_d$ without a numerical value or starting height.

For a separate range of degrees, Appendix B proves

$$
 \omega_d(\pi)\le \frac{208}{25}d\log d+d-2\quad(d\ \text{sufficiently large}),\qquad
 \limsup_{d\to\infty}\frac{\omega_d(\pi)}{d\log d}\le 8.32.              \tag{2}
$$

In (2) the height tends to infinity for each fixed degree before the degree tends to infinity. The threshold on $d$ is unspecified. A bound $\omega_d(\pi)=o(d\log d)$ would require the normalized exponent to tend to zero and remains an open direction here.

Nesterenko and Waldschmidt give an explicit general-degree bound and a multiplicity estimate for exponential interpolation. With $\mathcal L(P)\le L_1$, $L_1\ge3$, their polynomial-value estimate reads $\log|P(\pi)|\ge-2\cdot10^6d(\log L_1+d\log d)(1+\log d)$ [1, Theorem 2(2) and Lemma 2]. For each fixed $d$, the coefficient of $\log L_1$ in the negative exponent gives a height exponent $2\cdot10^6d(1+\log d)$. Alexencev studied approximation of $\pi$ by algebraic numbers with explicit dependence on degree and height [2]. These are related problems because a small value of $P(\pi)$ involves the distances to all of its roots. The distinction already appears for $P(Y)=qY^3-p$, which tests a particular rational approximation to $\pi^3$. Theorem 1 allows all four coefficients to vary. Its proof below is independent of any irrationality measure for a power of $\pi$.

Sections 2–4 construct the nonzero integer and control its algebraic size. Sections 5–6 bound the determinant near $\pi$. Section 7 combines these estimates over all conjugates. Section 8 and Appendix A give the data and the finite verification. All limiting estimates in Sections 2–8 fix the indicated shape before the height tends to infinity.

## 2. Heights, conjugate roots and a nonzero integer

Let $f(Y)=a\prod_{i=1}^{e}(Y-\alpha_i)$ be primitive and irreducible over $\mathbb Q$, with $1\le e\le d$. Primitive means that the coefficients have greatest common divisor one. Set $B_i=\max(1,|\alpha_i|)$ and $\mathcal M(f)=|a|\prod_i B_i$. The latter quantity, the multiplicative Mahler measure, is multiplicative by the root factorization. We shall use

$$
 H(f)\le \mathcal L(f)\le 2^e\mathcal M(f),\qquad
 \mathcal M(f)\le\mathcal L(f)\le(e+1)H(f).                             \tag{3}
$$

Expanding the product gives $\mathcal L(f)\le |a|\prod(1+|\alpha_i|)$. For the reverse bound, the circle mean of $\log|e^{it}-\alpha|$ is $\log\max(1,|\alpha|)$. For $|\alpha|<1$ integrate the real part of the power series for $\log(1-\alpha e^{-it})$. For $|\alpha|>1$ factor out $|\alpha|$ and apply the same argument. The unit-circle case follows radially by the integrability of $\log|\sin(t/2)|$. Adding these means for the roots and using $|f(e^{it})|\le\mathcal L(f)$ proves (3).

Put $X=\log\mathcal L(f)$. On a sequence with $X\to\infty$, pass to a subsequence of fixed degree. Order the roots so that $u_i=X^{-1}\log^+(B_i/|\pi-\alpha_i|)$ decreases, where $\log^+x=\max(0,\log x)$. Pass again so that $u_i\to c_i$ in $[0,+\infty]$. Then

$$
 \lim \frac{-\log|f(\pi)|}{X}=\sum_{i=1}^e c_i-1,\qquad
 \sum_{i=2}^e(i-1)c_i\le e-1.                                          \tag{4}
$$

For the first equality, $\log\mathcal M(f)=X+O_d(1)$ by (3), and $|\pi-\alpha_i|/B_i\le1+\pi$ bounds the cost of truncating the logarithm. The discriminant of $f$ is a nonzero integer, as follows from its symmetric root formula (or the determinant formula for the discriminant) and separability in characteristic zero. Its square root in absolute value is

$$
 1\le |\operatorname{disc} f|^{1/2}
   =\mathcal M(f)^{e-1}\prod_{i<j}\frac{|\alpha_i-\alpha_j|}{B_iB_j}.
$$

The triangle inequality about $\pi$ shows that each normalized difference is at most $2(1+\pi)\exp(-Xu_j)$ for $i<j$. Taking logarithms proves (4). In degrees two and three the second inequality reads $c_2\le1$ and $c_2+2c_3\le2$, respectively, for an irreducible polynomial of that exact degree. In particular $y=\sum_{i>1}c_i\le e-1$. If the first root is nonreal its conjugate has the same normalized distance, so $c_1=c_2$ and $\sum_i c_i-1\le 2e-3$. Subsequences may be chosen with a fixed real/nonreal alternative. For a violation of (1) the first root must therefore be real and tend to $\pi$. Even $c_1=+\infty$ can be tested below with a finite lower bound for $c_1$.

**The resultant.** For this real root $\alpha_1$, $[\mathbb Q(\alpha_1,i):\mathbb Q(\alpha_1)]=2$ because $\mathbb Q(\alpha_1)\subset\mathbb R$. The tower formula gives $[\mathbb Q(i,\alpha_1):\mathbb Q(i)]=e$. Thus $f$ is irreducible over $\mathbb Q(i)$. If $R\in\mathbb Z[i][Y]$ and $R(\alpha_1)\ne0$, it follows that $f$ and $R$ are coprime and

$$
 1\le|\operatorname{Res}(f,R)|
 =|a|^{\deg R}\prod_{i=1}^e |R(\alpha_i)|
 =\mathcal M(f)^{\deg R}\prod_{i=1}^e
               \frac{|R(\alpha_i)|}{B_i^{\deg R}}.                         \tag{5}
$$

For completeness, the Sylvester matrix represents $(U,V)\mapsto Uf+VR$ with $\deg U<\deg R$, $\deg V<e$. Its entries are Gaussian integers. Its determinant is nonzero precisely when the two polynomials have no common factor. To obtain the product formula, split the codomain by division by $f$. Removing the leading coefficients in the quotient block gives $a^{\deg R}$ up to sign. On the remainder block, multiplication by $R$ on $\mathbb C[Y]/(f)$ is diagonal in the evaluations at the distinct $\alpha_i$, with diagonal entries $R(\alpha_i)$. Formula (5) is where the bounds at different roots must refer to the same $R$.

## 3. An auxiliary determinant nonzero at a prescribed point

Fix positive rational bandwidths $1=u_0\ge\cdots\ge u_T$ and row masses $a_v>0$ at the integer nodes $-V\le v\le V$, with $L=\sum_v a_v=2\sum_j u_j$. Section 8 specifies two choices. For an integer $N\to\infty$, set $U_j=\lfloor u_jN\rfloor$. There is one column $(t,j)$ for each integer $|t|\le U_j$, and $n=\sum_{j=0}^T(2U_j+1)=LN+O(1)$ columns in total. With $Z=iY/2$, define

$$
 A_{v,\sigma;t,j}(Y)=2^j i^{vt}(\partial_t+vZ)^j p_\sigma(t),\qquad
 p_\sigma(t)=t^\sigma/\sigma! .                                           \tag{6}
$$

Here $\partial_t$ differentiates a polynomial before substitution of the integer $t$. A prefix at $v$ consists of the rows $0,\ldots,m_v-1$. Replacing their $p_\sigma$ by any polynomials of degree $\sigma$ with the same leading coefficients amounts to a triangular change of determinant one. A different leading coefficient rescales a prefix determinant by the product of the leading-coefficient ratios.

**Lemma 3.1 (selection).** Group the nodes by their residue modulo four. Let $B_J$ be the sum of the largest $J+1$ masses in each group, taking every available mass in shorter groups. If $B_J\ge2\sum_{j=0}^J u_j$ for $0\le J\le T$, then for any $\xi\ne0$ there are prefixes with $m_v=a_v N+O(1)$ giving a square determinant $R^0(Y)$ with $R^0(\xi)\ne0$. The error bound is independent of $\xi$.

*Proof.* Scan first through $h_v=\lfloor a_vN\rfloor+T+2$ rows at each node. A column dependence at $Y=\xi$ would give a nonzero Laurent polynomial $P(y,z)=\sum_{j=0}^JP_j(y)z^j$, $P_J\ne0$, with exponents of $P_j$ in $[-U_j,U_j]$. With $Z=i\xi/2$, the functions $P(i^ve^w,w+vZ)$ would vanish to order at least $h_v$ at $w=0$. Indeed the $w^\sigma$ coefficient of $(w+vZ)^je^{tw}$ is $(\partial_t+vZ)^jp_\sigma(t)$, and $2^j$ can be absorbed into column coefficients.

Set $\delta=y\partial_y+\partial_z$ and form

$$
 W(y,z)=\det\big(\delta^r\partial_z^k P(y,z)\big)_{0\le r,k\le J}.
$$

Translation $z\mapsto z+c$ acts by a triangular column operation with unit diagonal, by Taylor's formula and commutation with $\delta$. Thus $W$ is independent of $z$. Column $k$ has Laurent exponents between $-U_k$ and $U_k$ because the bands are nested. Consequently the exponent width (largest minus smallest exponent) of $W$ is at most $2\sum_{k=0}^JU_k$.

The determinant is nonzero. On a local branch $z=\log y$, the functions $(\partial_z^kP)(y,\log y)$ are independent over the constants. A nonzero linear combination has a highest power of $\log y$ whose coefficient is a nonzero Laurent polynomial. Continuing repeatedly about $0$ would give infinitely many zeros of a nonzero polynomial in $\log y$ at a fixed regular $y$. The determinant in question is their Wronskian, using $y\,d/dy$. To see the Wronskian test directly, change a basis of analytic germs by eliminating lowest Taylor coefficients until the leading orders are distinct. The leading determinant of ordinary derivatives is the Vandermonde in these orders times nonzero leading coefficients. The operator $y\,d/dy$ changes that determinant only by a nonvanishing factor locally at $y\ne0$.

At $y=i^r$ use $y=i^re^w$. Each selected $v\equiv r\bmod4$ gives the linear combination of columns with coefficients $((vZ)^k/k!)_{0\le k\le J}$. Up to $J+1$ such vectors are independent by the Vandermonde formula. Complete them to a constant basis. In the Wronskian at that point a function vanishing to order $h_v$ contributes at least $(h_v-J)_+$ zeros, where $x_+=\max(x,0)$. Across the four distinct points the total exceeds $NB_J$ and hence is larger than the Laurent width. Multiplying $W$ by a monomial gives an ordinary nonzero polynomial of that width, a contradiction.

It remains to retain prefixes. Use monomials temporarily and scan rows in increasing order of $\sigma-\lfloor a_vN\rfloor$, breaking ties by one fixed order of $v$. Keep each independent row. Multiplication of a row polynomial by $t$ acts by the same right-hand matrix at every node, since

$$
 (\partial_t+vZ)^j(tp)=t(\partial_t+vZ)^jp+j(\partial_t+vZ)^{j-1}p .
$$

The second term uses an existing column if $j>0$. Any dependence therefore shifts to a dependence of the next row on earlier shifted rows. The scan can be viewed as infinite and stopped at rank $n$, reached by the common terminal key corresponding to $h_v-1$. Thus once skipped, a node never contributes a later row. There are $n+O(1)$ candidates up to that key, so $m_v=a_vN+O(1)$. Restoring the factorial normalization preserves nonvanishing. $\square$

## 4. Degree and denominators of the auxiliary polynomial

Within each residue class order nodes by decreasing $m_v$ and assign ranks $q_v=0,1,\ldots$. In the limiting sums the order is decreasing $a_v$, with ties contributing equal masses. Put

$$
 \bar j=\frac{2\sum_j ju_j}{L},\qquad \bar q=\frac{\sum_v q_va_v}{L},
 \qquad s=\frac{\sum_v a_v^2}{2L},\qquad b_j=\frac{u_j}{2}.                \tag{7}
$$

**Lemma 4.1 (degree).** The determinant $R^0$ is divisible by $Y^{L_0}$ with $L_0=\sum_vq_vm_v$. If $\zeta$ ranges over $\{0,u_0,\ldots,u_T\}$, set

$$
 \rho(\zeta)=-1+\frac{2\sum_j\min(\zeta,u_j)+
                   \sum_{v=-V}^{V}\sum_{k\ge0}(a_v-2\zeta-2k)_+}{L},
 \qquad D=\bar j-\bar q-\max_\zeta\rho(\zeta).                             \tag{8}
$$

Only finitely many terms in the sum over $k$ are positive. Then $\deg(R^0/Y^{L_0})\le n(D+o(1))$.

*Proof.* At fixed $\sigma$ and fixed residue all phases $i^{vt}$ agree. Replace the row at $v$ by its Newton divided difference on the first $q_v+1$ nodes in that group. To recall, the order-$q$ difference maps $g$ to $\sum_{h=0}^q g(v_h)/\prod_{r\ne h}(v_h-v_r)$, the leading coefficient of its interpolation polynomial. It kills powers of $v$ below $q$. In (6) every $v^h$ remaining after removal of the common phase carries $Y^h$. Thus $Y^{q_v}$ divides each transformed row. The change has nonzero constant determinant, proving the origin assertion.

At the other end fix $\zeta$, put $H_0=2U_0+1$, $H_\zeta=2\lfloor\zeta N\rfloor+1$, and $r_\sigma=\lfloor(\sigma-H_\zeta)/H_0\rfloor$. When $r_\sigma\ge0$, choose a degree-$\sigma$ row polynomial with zeros of multiplicities $r_\sigma+\mathbf1_{|t|\le\zeta N}$ at the integer frequencies of layer zero. These multiplicities total at most $\sigma$. Multiply by a monomial and normalize the leading term. When $r_\sigma=-1$, impose no zeros. Every nonzero entry needs at least $r_\sigma+\mathbf1_{|t|\le\zeta N}$ derivatives of its row polynomial. Each derivative lowers its possible $Y$-degree by one. Sum this loss over a determinant permutation. The average of the column indicator tends to $2\sum_j\min(\zeta,u_j)/L$. The average of $r_\sigma$ tends to $-1+L^{-1}\sum_v\sum_{k\ge0}(a_v-2\zeta-2k)_+$ by counting the rows $\sigma\ge H_\zeta+kH_0$. Subtract the origin order as well to obtain (8). $\square$

**Lemma 4.2 (denominators).** There is an integer $B_N>0$ for which $R=B_NR^0/Y^{L_0}\in\mathbb Z[i][Y]$ and $\log B_N\le (G+o(1))nN$. The following finite formula is valid. Put $A=\max(\max a_v,\max b_j)$ and take either $\eta=1/30$ or $\eta=1/24$. For $y\ge\eta$ define

$$
 \begin{aligned}
 R_h(y)&=L^{-1}\sum_v(a_v-(h-q_v)_+y)_+,&
 C_h(y)&=4L^{-1}\sum_j(b_j-(h-j)_+y)_+,\\
 F_\eta(x)&=\sum_{m\ge1}\frac{(x-m\eta)_+^2}{2m}.&&
 \end{aligned}
$$
$$
 \begin{aligned}
 G_\eta={}&\eta(\bar j-\bar q)+
 \frac{\sum_v F_\eta(a_v)-4\sum_j F_\eta(b_j)}{L}\\
 &-\sum_{h\ge1}\int_\eta^{A}(R_h(y)-C_h(y))_+\,dy,\qquad
 G=\min(G_{1/30},G_{1/24}).
 \end{aligned}\tag{9}
$$

*Proof.* Work one rational prime $p$ at a time on both rational components of Gaussian coefficients. Let $S=\max m_v+2U_0+2$. For $p\le\sqrt S$ use the row basis $\binom t\sigma$. On polynomials of degree at most $S$, differentiation equals $\log(1+\Delta)=\sum_{k=1}^S(-1)^{k-1}\Delta^k/k$, where $\Delta p(t)=p(t+1)-p(t)$. This follows by expanding the translation operator $\exp(\partial_t)$ on the finite polynomial space. Differences of integer-valued polynomials stay integer-valued. Thus one derivative costs at most $\lfloor\log_p S\rfloor$ powers of $p$, and $2^j$ clears the powers of two from $Z$. The sum of logarithmic costs in this range is $O_T(n\sqrt S\log^2 S)=o(nN)$, even bounding the number of primes by $\sqrt S$.

For larger $p$ use $4^\sigma\binom{(t+U_0)/4}{\sigma}$, with the same leading term. In each column class $(j,l)$, $t\equiv l\bmod4$, let $t_{jl}$ be the first frequency. Take successive forward differences in $(t-t_{jl})/4$. This triangular column operation has determinant one. Its $k$th difference inserts $x^k$ in the generating series $(1+x)^{(t+U_0)/4}$. Up to $p$-units, the entries are

$$
 [x^{\sigma-k}](1+x)^{(t_{jl}+U_0)/4}
        \big(vZ+\tfrac14\log(1+x)\big)^j .                               \tag{10}
$$

For odd $p$, every coefficient of the rational power is $p$-integral, meaning its denominator in lowest terms is prime to $p$. Indeed, for the coefficient $\binom{\lambda}{r}$ with $4\lambda$ integral, take an integer $m\ge r$ with $4m\equiv4\lambda\pmod {p^{v_p(r!)+1}}$, possible since $p$ is odd. The two falling products of $r$ factors agree to that precision. The one at $m$ is $r!\binom mr$, so division by $r!$ introduces no $p$ in the reduced denominator of the one at $\lambda$. The row divided difference kills powers of $v$ below $q_v$, leaving at most $j-q_v$ logarithm factors. Node differences are units for these $p$ once $N$ is large. A logarithm coefficient of degree $\le S$ has at most one $p$ in its denominator, and such a term costs at least $p$ degrees in $x$. A nonzero entry requires $\sigma\ge k$, $j\ge q_v$. Its denominator exponent is therefore at most

$$
 \min\big(j-q_v,\ \lfloor\sigma/p\rfloor-\lfloor k/p\rfloor\big).
$$

The first bound summed over a permutation is $\sum j-\sum q_v$ (with row and column multiplicities). The second sum can be diminished by at least

$$
 E_p=\sum_{h\ge1}
 \big(\#\{\text{rows}:\lfloor\sigma/p\rfloor+q_v\ge h\}
       -\#\{\text{columns}: j+\lfloor k/p\rfloor\ge h\}\big)_+ .          \tag{11}
$$

Indeed, for each matched row and column the saving is the positive part of the difference of the two integer levels in (11). At height $h$, each surplus row above that level must match a column below it. Sum over $h$. All coefficients obey the same bounds. Restoring the original determinant multiplies by fixed node differences, which introduce no new large-prime denominators.

Use the first bound up to $p\le\eta N$. The prime number theorem in the form $\vartheta(x)=\sum_{p\le x}\log p=x+o(x)$ [3] gives the first term in (9). For $p/N=y\ge\eta$, the normalized counts in (11) are $R_h(y)+O(1/N)$ and $C_h(y)+O(1/N)$ because one column class has $b_jN+O(1)$ consecutive differences, and there are four classes per layer. Only boundedly many $h$ occur. For example the normalized sum of $\lfloor\sigma/p\rfloor$ for a row prefix of length $xN+O(1)$ is $L^{-1}\sum_{m\ge1}(x-my)_++O(1/N)$. Its integral from $\eta$ to $A$ is $F_\eta(x)/L$. The same count for the four column classes is subtracted. Prime sums weighted by $\log p/N$ converge to these integrals by the prime number theorem on fixed intervals followed by approximation by step functions. Beyond $AN+O(1)$ the floor cost is zero. Multiplying the primes to their verified nonnegative integer powers clears every coefficient. This proves (9). $\square$

## 5. The size of a determinant along the boundary

Divide each frequency by $N$. The limiting distribution of all columns, each with mass $1/N$, is $\nu(dx)=\sum_j\mathbf1_{[-u_j,u_j]}(x)\,dx$. Its total mass is $L$. Call $(\mu_v)$ admissible if $\mu_v\ge0$, $\sum_v\mu_v=\nu$ and $\int d\mu_v=a_v$. Each has a density bounded by $T+1$. Put $m_v(\mu)=\int x\,d\mu_v(x)$ in this section only. We use $m_v$ without an argument for an integer number of rows. Define

$$
 \begin{aligned}
 I(\mu,\rho)&=\iint\log(2|x-y|)\,d\mu(x)d\rho(y),\\
 \mathcal F(\mathbf k)&=\frac1L\sup_\mu\sum_v
       \left(k_v m_v(\mu)+\tfrac12 I(\mu_v,\mu_v)\right),\\
 A_0&=\frac1{2L}\sum_v a_v^2\big(\tfrac32-\log(2a_v)\big).
 \end{aligned}                                                            \tag{12}
$$

Here $\sup_\mu$ ranges over admissible distributions on $[-1,1]$. The kernel is integrable across the diagonal for bounded densities. Subscripts on $f_0$ denote the zero field, independently of the minimal polynomial $f$. Let $f_0$ be a certified upper bound for $\mathcal F(\mathbf0)$. For the integral polynomial of Lemma 4.2,

$$
 \log\mathcal L(R)\ \le\ nN(A_0+G+f_0+o(1)).                              \tag{13}
$$

To prove this and its boundary variant, expand the determinant by row blocks indexed by $v$. For the $m=m_v$ columns assigned to one block and any orders $0\le j'_c\le T$, remove column phases and constants. For bounded $z_v$ the remaining block equals

$$
 \det\big((\partial_{t_c}+z_v)^{j'_c}p_\sigma(t_c)\big)_{\sigma,c}
 =\frac{\prod_c(\partial_{t_c}+z_v)^{j'_c}\,
               \prod_{c<c'}(t_{c'}-t_c)}{\prod_{\sigma=0}^{m-1}\sigma!}.   \tag{14}
$$

This is the Vandermonde identity followed by one differential operator per column. The variables $t_c$ are differentiated independently and may afterwards be set equal. Cauchy's derivative estimate on the circle of radius one in each variable bounds the numerator by $C_{T,z_v}^{m}\prod_{c<c'}(|t_{c'}-t_c|+2)$. There are at most $(2V+1)^n$ assignments, negligible on taking logarithms and dividing by $nN$. Stirling's formula [4] and summation give $\sum_{\sigma<m}\log(\sigma!)=\frac12m^2\log m-\frac34m^2+O(m\log(2m))$. This cancels the powers of $N$ from the pair differences.

For detail on the limiting step, the empirical block measures $N^{-1}\sum_c\delta_{t_c/N}$ have weakly convergent subsequences on a compact interval. Equivalently one may extract distribution functions on a dense countable set and use continuous test functions. Their sum tends to $\nu$, hence each limit is admissible with bounded density. For fixed $\epsilon>0$, bound $\log(|x-y|+2/N)$ by $\log\max(|x-y|,\epsilon)+\log(1+2/(N\epsilon))$. The first kernel is continuous and the diagonal correction after division by $nN$ tends to zero. First take the weak limit, then $\epsilon\downarrow0$ by integrability. This gives the pair term $\sum I(\mu_v,\mu_v)/(2L)$ after moving the constant $\log 2$ into $A_0$. Additional column factors $\exp(t_c z_v)$ give the linear field $k_v=\operatorname{Re}z_v$. For (13) there is no such factor. Take the maximum on $|Y|=1$ and apply Cauchy's coefficient bound, which costs at most a factor $\deg R+1$. Division by $Y^{L_0}$ preserves the unit-circle norm, and $B_N$ contributes $G$.

**A computable upper bound.** For signed measures with bounded real densities write $U_\rho(x)=\int\log(2|x-y|)\,d\rho(y)$. If $\rho_v$ are any such references and $\beta_v$ any real numbers, then

$$
 L\mathcal F(\mathbf k)\le
 -\tfrac12\sum_v I(\rho_v,\rho_v)+\sum_v\beta_va_v+
 \int\max_v\big(k_vx+U_{\rho_v}(x)-\beta_v\big)\,d\nu(x).                \tag{15}
$$

Indeed $I(\lambda,\lambda)\le0$ for every bounded signed density $\lambda$. To see this, write $x=\cos\theta$, $y=\cos\phi$ and $T_j(\cos\theta)=\cos(j\theta)$ [5]. Expand $\log|1-re^{it}|=-\sum_{j\ge1}r^j\cos(jt)/j$ for $r<1$ at $t=\theta+\phi,\theta-\phi$, then let $r\uparrow1$. The two logarithms add to $\log(2|x-y|)$ in the limit. For $r\ge1/2$, $|1-re^{it}|^2=(1-r)^2+4r\sin^2(t/2)$ bounds each negative part by a constant plus $|\log|\sin(t/2)||$, integrable on the angle square. Therefore

$$
 I(\lambda,\lambda)=-2\sum_{j=1}^{\infty}
            \frac{\big(\int T_j\,d\lambda\big)^2}{j}\le0 .
$$

Apply this to $\lambda=\mu_v-\rho_v$, expand the square, and add the mass identities $\beta_v\int d\mu_v=\beta_va_v$. The sum of the remaining integrals against $\mu_v$ is bounded by the integral of their pointwise maximum against $\nu$. This proves (15) for every admissible $\mu$, hence for the supremum. Appendix A explains how the right side is enclosed on entire intervals.

## 6. Vanishing under perturbation and independent analytic paths

### 6.1. Expansion at a nearby point

Let $\theta=i\pi/2$, $\varepsilon=i(\alpha-\pi)/2$. The arithmetic progression of phases $e^{t\theta v}=i^{vt}$ is the reason for the choice of $\pi/2$. For a column of order $j$ its value at $\alpha$ has the exact expansion, with the harmless factor $2^j$ omitted,

$$
 i^{vt}(\partial_t+iv\alpha/2)^jp_\sigma(t)
 =\sum_{\ell=0}^j\binom j\ell\varepsilon^\ell v^\ell
      [p_\sigma(\partial_x)(x^{j-\ell}e^{tx})]_{x=\theta v}.              \tag{16}
$$

Expand the shifted power binomially and use $p(\partial_x)(x^m e^{tx})=e^{tx}(\partial_t+x)^mp(t)$ to verify (16). Fix a choice $\ell_c$ in every column and let $n_\ell$ count the selections equal to $\ell$. Choose a real $z\in(0,1)$ and real-coefficient functions $\psi_v$ analytic near the closed unit disk with $\psi_v(0)=0$, $\psi_v(z)=v$. In (16) substitute $x=\theta\psi_v(w)$ *after* differentiation, retaining $v^{\ell_c}$. This gives an analytic determinant $H(w)$ which reproduces exactly the chosen term at $w=z$, after the external binomials and $\varepsilon$ powers are restored.

**Lemma 6.1.** Its zero at $w=0$ has order at least

$$
 h=\sum_{\ell=0}^T\binom{n_\ell}{2}-\sum_v\binom{m_v}{2}.                 \tag{17}
$$

Expand $x^{j-\ell}e^{tx}$ into powers $x^k$. For fixed $\ell,k$ the vector down the rows is $v^\ell[p_\sigma(\partial_x)x^k]_{x=\theta\psi_v(w)}$, independent of the column apart from a scalar. Repeated $k$ within a label cannot contribute to a determinant. Distinct nonnegative integers for $n_\ell$ columns sum to at least $\binom{n_\ell}{2}$. A row derivative lowers the order by at most $\sigma$, and $\sum_{\rm rows}\sigma=\sum_v\binom{m_v}{2}$. These statements hold coefficient by coefficient in the Taylor series, since $k$ larger than the required order plus $\max\sigma$ does not contribute. This proves (17), also when its right side is negative.

On the boundary expand the *same entire determinant* by node, with all rows of a prefix present. Pull the exponential and $v^{\ell_c}$ factors from each assigned column of each block. The remaining determinant is (14) with $j'_c=j_c-\ell_c$. For fixed paths the auxiliary factors and all choices of labels cost $O_{T,V,\psi}(n\log n)$ in the logarithm. Section 5 gives the boundary upper rate $A_0+\mathcal F((\pi/2)\operatorname{Im}\boldsymbol\psi)$. The sign of the field can be reversed by reflecting all frequency measures. The error is uniform in the boundary point and in all assignments. A failure of uniformity would allow one to take a violating sequence with a convergent boundary point and weak limits, contradicting the truncated-kernel bound there.

Write $\mathbb E_z$ for probability integration with density $(1-z^2)/(2\pi|e^{i\varphi}-z|^2)$ on the unit circle. Subharmonicity gives $\log|H(z)|\le h\log z+\mathbb E_z\log|H(e^{i\varphi})|$ by dividing by the actual zero at the origin and applying the Poisson majorant for the logarithm of an analytic function. Boundary zeros follow by regularization or an interior limiting circle. A zero determinant satisfies the upper bound as well. Define $\mathcal B_z$ as the infimum of $\mathbb E_z\mathcal F((\pi/2)\operatorname{Im}\boldsymbol\psi)$ over the paths above.

If $N=\lfloor bX\rfloor$, $b>0$, and $|\alpha-\pi|\le \exp(-(c-o(1))X)$ for $c>0$, put $\kappa=\log(1/z)$ and $B=b\kappa L/2$. Using (16)–(17) and $R=B_NR^0/Y^{L_0}$ gives

$$
 \begin{aligned}
 \limsup\frac{\log|R(\alpha)|}{nX}
 &\le b(A_0+G+\kappa s+\mathcal B_z)-F_B(c),\\
 F_B(c)&=\min_{\substack{p_0,\ldots,p_T\ge0\\ \sum p_\ell=1}}
        \left(c\sum_\ell \ell p_\ell+B\sum_\ell p_\ell^2\right).
 \end{aligned}                                                            \tag{18}
$$

Indeed $p_\ell=n_\ell/n$, $\sum_\ell\binom{n_\ell}{2}/(nX)=(bL/2)\sum p_\ell^2+o(1)$, and $\sum_v\binom{m_v}{2}/(nX)=bs+o(1)$. The perturbation contributes $-c\sum\ell p_\ell$, and enlarging the feasible proportions to the full simplex provides an upper bound for all terms. Since $\alpha\to\pi$, division by $\alpha^{L_0}$ can only improve the bound eventually. Fixing the paths before taking $X\to\infty$ justifies the later infimum. The derivation works at any nearby complex conjugate, even if another root was used to select $R$.

### 6.2. Bounding the mean over paths

Write $H_*(\mathbf d)=L^{-1}\max_\mu\sum_v d_v m_v(\mu)$. Reflection of $x$ makes both $H_*$ and $\mathcal F$ even. Directly from (12), $\mathcal F$ is convex and $\mathcal F(\mathbf k+\mathbf d)\le\mathcal F(\mathbf k)+H_*(\mathbf d)$. Both functions are Lipschitz since all masses and $|x|$ are bounded. If $d_v$ increases with $v$, divide $\nu$ from left to right into consecutive intervals of masses $a_{-V},\ldots,a_V$ and call the resulting moments $m_v^*$. Then $H_*(\mathbf d)=L^{-1}\sum_v d_vm_v^*$. To prove this, decompose the sum by the nonnegative increments $d_v-d_{v-1}$. For each upper tail of nodes its moment is at most the moment of the rightmost interval having its mass, and the ordered division attains every such bound. Set $Q=L^{-1}\sum_v v m_v^*$. Symmetry gives $m_{-v}^*=-m_v^*$.

Take a bounded vector step function $\mathbf k$ on the first quadrant of the circle. Reflect it evenly across the imaginary axis, then oddly across the real axis to form $\widetilde{\mathbf k}$. In formulas involving $S=|\sin\varphi|$ write $\mathbf k$ for the original values folded back into the first quadrant and use the folded probability. Set $A_z=\pi(z^{-1}-z)/4$. If $d_v=A_z v-\mathbb E_z[Sk_v]$ is increasing with $v$, then

$$
 \mathcal B_z\le Q A_z-
 \mathbb E_z\left[S\sum_v k_v m_v^*/L-\mathcal F(\mathbf k)\right].       \tag{19}
$$

Here the freedom to specify different bounded functions at different nodes is compatible with the exact equalities $\psi_v(z)=v$. For a real-coefficient analytic polynomial $g$ with $g(0)=0$,

$$
 \mathbb E_z[(\pi/2)\operatorname{Im}g(e^{i\varphi})\sin\varphi]=A_zg(z).
                                                                            \tag{20}
$$

For $g(w)=w^k$, the average of $\sin(k\varphi)\sin\varphi$ is $(z^{k-1}-z^{k+1})/2$ by the cosine product formula and the Poisson kernel. Linearity proves (20). Approximate $(2/\pi)\widetilde k_v$ in $L^1$ by its Fejér means, which are finite sine sums. Indeed the Fejér kernel is nonnegative, has mass one, and its mass outside any fixed neighborhood of zero tends to zero, so bounded step functions converge away from their finitely many jumps and hence in $L^1$. As the Poisson density is bounded for fixed $z$, the same convergence holds with this weight. A sine sum is the imaginary part of a real-coefficient polynomial $g_v(w)$ without constant term. Formula (20) then gives $A_zg_v(z)\to\mathbb E_z[Sk_v]$.

For $0<t<1$ set $p_t(w)=(z^{-1}+tz)w/(1+tw^2)$ and take $\psi_v=g_v+(v-g_v(z))p_t$. Both endpoint conditions hold. On the circle,

$$
 \operatorname{Im}p_t(e^{i\varphi})
 =\frac{(z^{-1}+tz)(1-t)\sin\varphi}{(1-t)^2+4t\cos^2\varphi}.
$$

The difference $|\operatorname{Im}p_t|-\sin\varphi\,\operatorname{Im}p_t$ lies between zero and $(z^{-1}+tz)(1-t)/(4t)$, since $1-|\sin\varphi|=\cos^2\varphi/(1+|\sin\varphi|)$. Formula (20), valid also for $p_t$ by uniform convergence for fixed $t$, gives $\mathbb E_z[(\pi/2)|\operatorname{Im}p_t|]\to A_z$. By evenness and positive homogeneity of $H_*$ the mean cost of the correction tends to $A_zH_*((v-g_v(z))_v)$. Pass to the step-function limit using Lipschitz continuity. The corrected mean is at most $\mathbb E_z\mathcal F(\mathbf k)+H_*((d_v)_v)$. The ordered-interval formula for $H_*$ gives (19). In particular scalar paths $\psi_v=vp_t$ always give the simpler bound

$$
 \mathcal B_z\le f_0+QA_z=f_0+(\pi/2)Q\sinh\kappa.                       \tag{21}
$$

## 7. Combining the estimates and passing to all polynomials

Let $C=w_d+1$. For the principal root use (19) with a verified upper value $\mathcal B$ and apply (21) at other roots. Put $g=A_0+G+f_0$, using certified upper values throughout. The numerical conditions we need are

$$
 F_B(C)> D+b\{d(A_0+G)+(d-1)f_0+\kappa s+\mathcal B\}.                  \tag{22}
$$

Here and below one may use $B=bL\kappa_-/2$ with $\kappa_-\le\kappa$, since $F_B$ is increasing in $B$. On the right an upper enclosure for $\kappa$ is used. If $2B/3\le c\le2B$, then

$$
 F_B(c)=B-\frac{(2B-c)^2}{8B},\qquad
 F'_B(c)=\frac{2B-c}{4B}.                                                 \tag{23}
$$

Indeed $p_1=(2B-c)/(4B)$, $p_0=1-p_1$ have equal marginal cost $2Bp_0=c+2Bp_1=(2B+c)/2$. All inactive coordinates $\ell\ge2$ have cost at least $2c\ge(2B+c)/2$. By convexity this is a minimum, including both endpoints. If $2B/3<C-d+1<C<2B$, the loss from replacing $C$ by $C-y$, $0\le y\le d-1$, is at most $my$, where

$$
 m=\frac{2B-C+d-1}{4B},\qquad
 h_*=\frac{d-1}{bL},\qquad
 \gamma=\frac12-\frac{s}{L}-\frac{\pi Q}{2L(1-h_*^2)}.                  \tag{24}
$$

Any secondary root with $c_i>0$ tends to $\pi$ and satisfies $|\pi-\alpha_i|=\exp(-(c_i+o(1))X)$ because a vanishing normalized distance forces $\alpha_i$ and hence $B_i$ to be bounded. Apply (18), (21) with $\kappa_i=c_i/(bL)$. This gives $2B_i=c_i$ and $F_{B_i}(c_i)=c_i/2$. Its gain over the ordinary length estimate $bg$ is at least $\gamma c_i$, since $c_i/(bL)\le h_*<1$ and $\sinh x\le x/(1-x^2)$ by the power series. For $c_i=0$, (13) bounds $\log(|R(\alpha_i)|/B_i^{\deg R})/(nX)$ by $bg+o(1)$. The same normalization can only improve the estimates for roots with $c_i>0$.

Suppose $\sum c_i\ge C$ and put $y=\sum_{i>1}c_i$. By (4), $y\le d-1$ and $c_1\ge C-y>0$. The latter finite threshold suffices in (18), also if $c_1=+\infty$. Apply (5), use $\log\mathcal M(f)\le X$, and bound the $e-1$ secondary terms as above. The upper limit of $\log|\operatorname{Res}(f,R)|/(nX)$ is at most

$$
 D+b\{d(A_0+G)+(d-1)f_0+\kappa s+\mathcal B\}
       -F_B(C)+(m-\gamma)y .                                              \tag{25}
$$

Replacing $e$ by $d$ here is valid because $g\ge0$. If (22) holds and $\gamma\ge m$, (25) is strictly negative. This contradicts (5). Hence no such root sequence exists.

To recover the endpoint constant, if $\inf_f H(f)^{C-1}|f(\pi)|=0$ over the primitive irreducibles of degree at most $d$, choose a sequence along which the product tends to zero. A bounded-height subset is finite, and no such polynomial vanishes at $\pi$ by its transcendence (also a consequence of the Hermite–Lindemann theorem applied to $i\pi$ [1]). Thus $X\to\infty$ on a subsequence. Since $\log H(f)=X+O_d(1)$, (4) would give $\sum c_i\ge C$. This proves a uniform positive lower constant for all those irreducibles.

Finally write $P=h\prod_{k=1}^r f_k$ with $r\le d$, counting multiplicity, and $h$ a nonzero integer. By (3) the inequality for each $f_k$ implies $|f_k(\pi)|\ge c'_d\mathcal M(f_k)^{-w_d}$ with $0<c'_d\le1$. Multiply, using $|h|\ge1$, $\mathcal M(P)=|h|\prod_k\mathcal M(f_k)$ and $\mathcal M(P)\le(d+1)H(P)$. One may take $(c'_d)^d(d+1)^{-w_d}$ for $c_d$, also for a constant polynomial. This completes the proof of Theorem 1 subject only to the finite inequalities in Section 8.

## 8. Parameters and numerical inequalities

For both cases take the masses $a_v=Lr_{|v|}/(r_0+2\sum_{h=1}^V r_h)$. The following lists are integers, in order from $j=0$ or $|v|=0$. They specify all bands and masses exactly.

$$
\begin{aligned}
 d=2:\quad 10^4\mathbf u={}&(10000,9408,8756,8080,7358,\\
 &6574,5744,5460,4484,3256),\\
 \mathbf r={}&(10000,9434,8482,6139).
\end{aligned}
$$
$$
\begin{aligned}
 d=3:\quad 10^4\mathbf u={}&(10000,9745,9400,9044,8686,8318,\\
 &7940,7547,7140,6714,6260,6122,\\
 &5634,5096,4504,3834,3004,1920),\\
 \mathbf r={}&(10000,9812,9657,9107,8129,6640,3684).
\end{aligned}
$$

The lengths are $L=1728/125$ and $30227/1250$. For $J<T$, the smallest selection slack $B_J-2\sum_{j\le J}u_j$ is respectively $407/625$ and $48/125$. The last slack is exactly zero in both cases. Thus Lemma 3.1 applies. **Table 1** gives exact $b,z,C$ and upper bounds for the remaining quantities, using (19) for $\mathcal B$.

| $d$ | $b$ | $z$ | $C$ | $D$ | $G$ |
|:---:|---:|---:|---:|---:|---:|
| 2 | 1.085932 | .16741 | 17.1942 | 3.087798599 | 2.122800317 |
| 3 | 1.065662 | .16102 | 28.4188 | 5.628721405 | 2.545131654 |

| $d$ | $A_0$ | $Q$ | $f_0$ | $\mathcal B$ |
|:---:|---:|---:|---:|---:|
| 2 | .084130974 | .815618183 | $-.3573967591$ | 2.837884852 |
| 3 | .093580139 | 1.462388866 | $-.3468092793$ | 6.023875179 |

To obtain $Q$, the positive cut $x$ for an upper tail of mass $a$ solves $\sum_j(u_j-x)_+=a$ and the tail's first moment is $\frac12\sum_j(u_j^2-x^2)_+$. Both are rational. To obtain $G$, integrate each positive part of an affine function in (9). For endpoints $l<r$ with respective values $u>0>v$, its positive integral is $(r-l)u^2/(2(u-v))$. The roles of the endpoints may be interchanged. These two calculations require no numerical quadrature.

For (22) the lower bound for $F_B(C)$ and the upper bound for its right side are respectively $12.5501790262$ and $12.5501598073$ in degree two, $21.6842515238$ and $21.6842204255$ in degree three. The following strict inequalities come from the unrounded enclosures.

| $d$ | $\text{gap in (22)}$ | $\gamma$ | $m$ |
|:---:|---:|---:|---:|
| 2 | $>0.000019218$ | $>0.33327961$ | $<0.198218$ |
| 3 | $>0.000031098$ | $>0.36322111$ | $<0.219312$ |

**Table 2.** The surplus in the principal-root inequality and the slopes for other roots. In both cases $g>0$, $0<h_*<1$, and $2B/3<C-d+1<C<2B$. The smallest of the adjacent differences $d_v-d_{v-1}$ in (19) exceeds $0.00004999$. These checks establish all the assumptions used in (25), and prove (1).

## Appendix A. Finite certificates for the space and angle variables

**A.1. Witness data.** The accompanying archive contains one JSON input for each degree. Each gives the integer bands and row weights of Section 8, the exact $b,C,z$, and all reference fields actually used. A field contains one vector $(k_v)$, charges $(\beta_v)$ and 80 equal-width bins of reference density on $[-1,1]$ for $0\le v\le V$. All three arrays are integer numerators in units of $10^{-5}$. For negative $v$, reflect the density in $x$, put $\beta_{-v}=\beta_v$ and $k_{-v}=-k_v$. The zero-node density is even. There are 54 and 50 reference fields, respectively, including the zero-field witness for $f_0$. The charges and reference densities in (15) are arbitrary, so the verification does not depend on how the inputs were found.

**A.2. Integrating a reference field.** Set

$$
 F(x)=x(\log(2|x|)-1),\qquad J(x)=\tfrac12x^2\log(2|x|)-\tfrac34x^2,
 \qquad F(0)=J(0)=0 .
$$

Then $J'=F$ and $F'(x)=\log(2|x|)$ off the origin. A constant density $r$ on $[l,h]$ contributes $r(F(x-l)-F(x-h))$ to its potential. A pair of unit densities on $[a,b],[c,d]$ contributes $J(b-c)-J(a-c)-J(b-d)+J(a-d)$ to $I$. Thus the only spatial integral in (15) still needing enclosure is the pointwise maximum.

Take mesh width $\delta=1/10000$ on $[-1,1]$. All density jumps and band endpoints lie on it. Linearly interpolate each candidate inside a cell. The chord between the two endpoint maxima dominates the maximum of the chords. For a single translated $F$ the two cells next to its singularity each have integrated absolute interpolation error at most $\delta^2/2$. Indeed, after removing the linear part this is $\delta^2\int_0^1|u\log u|\,du=\delta^2/4$. In a cell at distance at least $j\delta$ the ordinary interpolation remainder gives $\delta^2/(8j)$ after integration since $|F''|\le1/(j\delta)$. Sum on both sides and use $\sum_{j\le 2/\delta}1/j\le1+\lceil\log_2(2/\delta)\rceil$. A valid total allowance for the integral of the maximum is

$$
 (T+1)\left(\sum_h\max_v|\Delta\rho_v(h)|\right)
 \delta^2\left(1+\frac{1+\lceil\log_2(2/\delta)\rceil}{4}\right).           \tag{26}
$$

Here $\Delta\rho_v(h)$ is the signed jump of the piecewise constant density at edge $h$, including both ends against zero. Indeed $U_{\rho_v}=\sum_h\Delta\rho_v(h)F(x-h)$, and the density of $\nu$ is bounded by $T+1$. Taking the maximum before this sum of absolute error bounds covers changes of active node inside a cell. The full envelope is even, so its trapezoid sum is twice the one on $[0,1]$.

For the logarithms of mesh differences, add consecutive increments

$$
 \log(k+1)-\log k=2\sum_{j\ge0}\frac{1}{(2j+1)(2k+1)^{2j+1}}.
$$

In units of $10^{-23}$ round each retained summand outward. Once the next term is less than one unit, the tail is less than two, by the ratio bound $(2k+1)^{-2}\le1/9$. The resulting primitive tables enclose $F$ and $J$ with absolute errors at most two units on scales $10^9$ and $10^{12}$ respectively. Signed products use absolute coefficients in their error budgets. A four-corner expression for $J$ costs at most eight units times the appropriate product of density norms. Integer matrix products are tested against their signed 64-bit ranges. Outer sums and rational arithmetic use arbitrary-precision integers. These rules explain the one-sided values supplied to (19).

**A.3. Exact angular masses.** For $\varphi\in[0,\pi/2]$ put $y=\tan(\varphi/2)$, $r=(1+z)/(1-z)$ and $c=(1-y^2)/(1+y^2)$. Let $W(y)$ denote cumulative folded Poisson mass and $J_z(y)$ cumulative folded integral of $S$. Addition of the four reflected densities yields

$$
 \begin{aligned}
 W(y)&=\frac2\pi\big(\arctan(ry)+\arctan(y/r)\big),\\
 J_z(y)&=\frac{1-z^2}{2\pi z}\left(2\log r-
            \log\frac{1+z^2+2zc}{1+z^2-2zc}\right).
 \end{aligned}                                                            \tag{27}
$$

For example the folded density per $d\varphi$ is $(1-z^2)\pi^{-1}[(1-2zc+z^2)^{-1}+(1+2zc+z^2)^{-1}]$. With $d\varphi=2dy/(1+y^2)$ its integral is $W$. Multiplication by $\sin\varphi$ and substitution $dc=-\sin\varphi\,d\varphi$ give $J_z$, with both primitives zero at $y=0$. Break $[0,1]$ into 256 equal cells and form the stated vector on each cell by convex combinations of the reference fields with positive weights in units of $10^{-8}$ summing to one. By convexity, the same combination of certified spatial upper bounds bounds the mixed field. Equal neighboring choices merge into 57 intervals for $d=2$ and 55 for $d=3$.

For an interval $[l,r']$ let $\Delta W=W(r')-W(l)$, $\Delta J=J_z(r')-J_z(l)$, and let $f$ bound $\mathcal F(\mathbf k)$. Add $\Delta J\sum_v k_vm_v^*/L-\Delta W f$ to the gain subtracted in (19). For each $v>0$ add $\Delta J(k_v-k_{v-1})$ to its normalization expense. Independent interval endpoints are used when subtracting, and multiplication by a negative rational reverses the endpoints. Compare all expenses with a lower bound for $A_z$. Finally evaluate (22)–(24) with directed intervals. Logarithms outside the mesh use the series $2\sum_{j\ge0}t^{2j+1}/(2j+1)$, $t=(x-1)/(x+1)$ after power-of-two reduction to $1\le x\le2$. A geometric tail encloses the remainder. The alternating arctangent series after reduction to $[0,1/2]$, together with $\pi=16\arctan(1/5)-4\arctan(1/239)$, supplies the other endpoints.

As a numerical trace in degree two, the rightmost node has mass $1768032/1210625$. Its left quantile is $86128/145275$, between $u_6$ and $u_5$, and solves $\sum_{j=0}^5(u_j-x)=1768032/1210625$. The first angular interval is $0\le y\le2/256$, assigned the zero field. Its contribution to the lower gain in (19) is $-\Delta W f_0>0$ although every direction expense on it is zero. This also tests the sign of the energy term.

The supplementary archive includes the input arrays, verifier and a machine-readable record of all final rational intervals. From the extracted directory run `python verify.py` using Python 3.10 or later with NumPy installed. To write a fresh record run `python verify.py --json results.json`. The program evaluates the raw spatial fields, arithmetic profiles, angular intervals and both transfers. The supplied output record is unnecessary for a replay.

## Appendix B. A separate estimate when the degree grows

We prove (2) to specify exactly what carries over to growing degrees. Write $\mathscr D=d\log d$. This appendix uses new parameters

$$
 a=33/8,\quad b=3/5,\quad c=6/7,\quad s=511/125,\quad C=208/25 .
$$

For a real algebraic root $\alpha\ne0$ of a primitive irreducible $f$ of degree at most $d$, put $X=\log\mathcal L(f)$ and suppose $|\alpha-\pi|<e^{-C\mathscr D X}$. Set

$$
 \begin{gathered}
 T=\lfloor a\mathscr D\rfloor,\quad V=\lfloor c\mathscr D\rfloor,\quad
 U=\lfloor bX\rfloor,\quad S=\lfloor sX\rfloor,\quad h=\lfloor X/\mathscr D\rfloor,\\
 H=2U+1,\qquad M=2V+1,\qquad n=(T+1)H .
 \end{gathered}
$$

Write $o_*(1)$ for a quantity whose absolute upper limit as $X\to\infty$ goes to zero when $d\to\infty$. All estimates below use this order. In particular $h\ge1$ for large $X$ at fixed $d$.

**B.1. Selecting low derivatives.** Put $B_l(x)=x(x+1)\cdots(x+l-1)/l!$, $B_0=1$, and $E_\sigma=B_h^{\lfloor\sigma/h\rfloor}B_{\sigma\bmod h}$. All are integer-valued on the integers. For every $|t|\le U$ and $0\le j\le T$ form a column. For $|v|\le V$, $0\le\sigma\le S$, take the entries

$$
 d_j i^{vt}(\partial_t+ivY/2)^jE_\sigma(t),\qquad
 d_j=(2\,\operatorname{lcm}(1,\ldots,h))^j .                              \tag{28}
$$

Choose independent rows at $\alpha$ in nondecreasing order of $\sigma$. On a run of $q$ consecutive frequencies keep all $T+1$ layers. The columns restricted to orders $0,\ldots,k$ have full rank $(T+1)q$ if $(k+1)M>(T+M)q$. We use here the classical multiplicity lemma [1, Lemma 2]. At $M$ points $(x_v,y_v)$ with distinct $x_v$ and $y_v\ne0$, a nonzero polynomial of bidegree at most $(T,q-1)$ cannot vanish with all derivatives of orders $0,\ldots,k$ for $\partial_x+y\partial_y$ under that strict inequality. To apply it take $(x_v,y_v)=(iv\alpha/2,i^v)$. A dependence of columns gives exactly that polynomial after shifting the lowest frequency to zero by a monomial in $y$. Along $(x_v+w,y_ve^w)$ the monomial is a nonvanishing factor. The polynomials $E_0,\ldots,E_k$ form a triangular basis of the operators of orders at most $k$.

For clarity, the needed complex case of the multiplicity lemma has a short proof. Write a putative polynomial as $\sum_{j=1}^KQ_j(x)y^{m_j}$ with $K\le q$, distinct $m_j$, and nonzero $Q_j$ of degree at most $T$. The Wronskian of $Q_j(x)e^{m_jx}$, after the exponential is removed, is $W_*(x)=\det((\partial_x+m_j)^rQ_j(x))_{0\le r<K,\,1\le j\le K}$. It has degree at most $KT$ and is nonzero, since its leading coefficient is the product of the leading coefficients of the $Q_j$ times the Vandermonde in the $m_j$. At $x_v$ take the constant linear combination with coefficients $y_v^{m_j}e^{-m_jx_v}$. It is the function on the above trajectory and vanishes to order at least $k+1$. Replacing a basis column by this combination shows that $W_*$ vanishes to order at least $(k+2-K)_+$ at each $x_v$. But $M(k+2-K)>Tq+M(q+1-K)\ge KT$, a contradiction.

Thus by $k_q=\lfloor(T+M)q/M\rfloor$ the whole scan has chosen at least $(T+1)q$ independent rows. For large $d$ then large $X$ it reaches $n$ by $S$, as $s-b(a/c+2)=1/2000>0$. Let $R^0$ denote the selected determinant in (28). It satisfies $R^0(\alpha)\ne0$ and its mean selected order is bounded by

$$
 \bar\sigma\le H^{-1}\sum_{q=1}^H k_q
 \le (T+M)(H+1)/(2M)\le (s/2+o_*(1))X .                                 \tag{29}
$$

**B.2. Integer lower bound.** If $\Delta$ is the forward difference, the identity for $\partial=\log(1+\Delta)$ in Lemma 4.2 shows that $\operatorname{lcm}(1,\ldots,h)\partial$ preserves integer-valuedness for polynomials of degree at most $h$. The product rule on the factors of $E_\sigma$ gives integrality of (28), including both components at $p=2$. For each odd $p>h$ the coefficients of $E_\sigma$ are already $p$-integral. In each fixed $j$ and residue class, with $H_l$ frequencies, take the $k$th column difference as in Section 4. Each entry is now a polynomial in the frequency index with $p$-integral coefficients, because the phase is constant. Its $k$th difference at zero is divisible by $k!$, as one sees by expanding powers into falling factorials using integer Stirling numbers. Hence $K=\big(\prod_l\prod_{k<H_l}k!_{>h}\big)^{T+1}$ divides every coefficient of $R^0$, where $k!_{>h}$ retains the odd primes larger than $h$.

In each group of identical $(\sigma,v\bmod4)$ divided differences yield $Y^{\binom{m}{2}}$ for a group of $m$ rows. There are at most $4(S+1)$ groups. Cauchy–Schwarz therefore gives a total origin order $l_0\ge n^2/(8(S+1))-n/2$. Thus $R=R^0/(KY^{l_0})\in\mathbb Z[i][Y]$ with degree at most $nT/2-l_0$ (take $l_0$ to be the sum of the group orders). Its resultant with $f$ is nonzero. By (5), (3), and the length bound on the remaining conjugates,

$$
 \log|R^0(\alpha)|\ge
 d\log K-(d-1)\log\mathcal L(R^0)-(nT/2-l_0)X .                          \tag{30}
$$

Here $|\alpha|>1$ eventually. Its $l_0$ factor was dropped, and $\mathcal L(R^0)/K=\mathcal L(R)\ge1$ permits replacing $\deg f$ by $d$.

We give the rates in (30). Since $\bar k=\sum_lH_l(H_l-1)/(2H)=U/4+O(1)$, Legendre's factorial count with $\lfloor k/p\rfloor\ge k/p-1$ gives $\log K/n\ge\bar k\sum_{h<p\le U}(\log p)/p-\vartheta(U)$. At fixed $d$, $U/h\to b\mathscr D$. By partial summation of the prime number theorem the sum tends to $\log(b\mathscr D)$. Thus $d\log K/(n\mathscr D X)\ge b/4-o_*(1)$.

All coefficients of $E_\sigma$ are nonnegative. The length in $Y$ of its unscaled entry in (28) is at most $(1+V)^T E_\sigma(U+T)$, by expanding $E_\sigma(t+\partial_x)x^j$ and bounding powers of $\partial_x$ on $x^j$ by $j^k(1+|x|)^j$. For integer $u\ge0$, $\binom{u+l}{l}\le [e(1+u/l)]^l$. For $0<l<h$ use $l\log(h/l)\le h/e$. It follows that $\log E_\sigma(U+T)\le\sigma[1+\log(1+(U+T)/h)]+h$. By (29), after expanding the determinant, the logarithm per row is at most

$$
 \log n+(T/2)\log(2\operatorname{lcm}(1,\ldots,h))+O_d(1)
       +h+\bar\sigma[1+\log(1+(U+T)/h)] .
$$

The log lcm is $O(h)$ by the prime number theorem, since prime powers of exponent at least two contribute $O(\sqrt h\log^2 h)$. As $\log(1+b\mathscr D)/\log d\to1$, multiplication by $(d-1)/(\mathscr D X)$ leaves at most $s/2+o_*(1)$. Finally $T/(2\mathscr D)\to a/2$ and $l_0/(n\mathscr D)\ge ab/(4s)-o_*(1)$. Formula (30) now reads

$$
 \frac{\log|R^0(\alpha)|}{n\mathscr D X}\ge -D_1-o_*(1),\qquad
 D_1=\frac a2+\frac s2-\frac b4-\frac{ab}{4s}.                            \tag{31}
$$

**B.3. Analytic upper bound.** Fix $z=4/39$, $t_0=9999/10000$, and let $p_{t_0}$ be the path of Section 6. At $w=z$, split each column in (28) into its value at $\pi$ and its difference between $\alpha$ and $\pi$. Continue the former by the entries $[E_\sigma(\partial_x)(x^j e^{tx})]_{x=(i\pi/2)v p_{t_0}(w)}$. At $w=z$ these reproduce the original phases. Keep the difference columns at the actual point. Each carries one factor $\alpha-\pi$, since $\partial_x(\partial_t+x)^j=j(\partial_t+x)^{j-1}$ as an operator derivative. The remaining polynomial parts obey the bound used in B.2 times a constant depending on $d$, as $|\alpha-\pi|\le1$.

By multilinearity followed by Laplace expansion one gets a $k$-column analytic minor and an $(n-k)$-column error minor. The analytic minor has origin order at least $\binom k2-kS$ by the distinct-powers argument of (17). The argument permits arbitrary selected derivative rows and any row operator of degree at most $S$. The number of minor choices and permutations contributes $O(n\log n)$ to the logarithm. For its boundary exponent sort the $k$ absolute frequencies and node indices in decreasing order. A given absolute frequency occurs at most $2(T+1)$ times, and an absolute node at most $2(S+1)$ times. The $j$th entries are bounded by $U-(j-1)/(2(T+1))+1$ and $V-(j-1)/(2(S+1))+1$. Pairing the two descending bounds maximizes the product sum. With $x=k/n$, $\eta=sc/(ab)>1$, this gives

$$
 \frac1{nUV}\sum_{\rm matched}|t v|\le J_\eta(x)+o_*(1),\qquad
 J_\eta(x)=\int_0^x(1-y)(1-y/\eta)\,dy
 =x-\tfrac12(1+1/\eta)x^2+\tfrac{x^3}{3\eta}.                            \tag{32}
$$

Indeed $2V(S+1)/n=\eta+o_*(1)$, and the Riemann sum error is $O(1/U+1/V+1/n)$ uniformly in $k$. Section 6 gives $B_*=\mathbb E_z|\operatorname{Im}p_{t_0}|\le(1-z^2)/(2z)+(z^{-1}+t_0z)(1-t_0)/(4t_0)$. Poisson's bound for the zero, (32) for the exponential, and the $n-k$ difference factors now yield

$$
 \frac{\log|R^0(\alpha)|}{n\mathscr D X}\le
 \max_{0\le x\le1}
 \{-C(1-x)-ab\log(1/z)x^2+(\pi/2)B_*bcJ_\eta(x)\}+o_*(1).               \tag{33}
$$

In this normalization $\binom{k}{2}/(n\mathscr D X)=abx^2+o_*(1)$ and $kS/(n\mathscr D X)=o_*(1)$. For the nonexponential part the per-row bound in B.2 with $\sigma\le S$ is $O(X(1+\log(1+b\mathscr D)))+O_d(1)$ after the height limit. The column cost is $O(Th+T)$ per row. Dividing both by $\mathscr D X$ makes them $o_*(1)$, explaining their absence in (33).

**B.4. A strict comparison.** The exact enclosures of Appendix A give $\log(39/4)>2.27726$, $\pi/2<355/226$, $B_*<4.824$. Put $g_*=(355/226)(4.824)bc$. It suffices to bound the cubic below on the unit interval. Put

$$
 p(x)=C(1-x)+2.27726\,abx^2-g_*J_\eta(x)-D_1 .                           \tag{34}
$$

On each of 128 equal subintervals write $p((h+t)/128)=\sum_{j=0}^3u_jt^j$. Its cubic Bernstein coefficients are $b_i=\sum_{j=0}^iu_j\binom ij/\binom3j$. Since the basis functions $\binom3i t^i(1-t)^{3-i}$ are nonnegative and sum to one, $p$ is bounded below by the smallest coefficient. Over all 512 rational coefficients the minimum equals $40243808891539/22705471488000000>1/1000$. The supplementary verifier recomputes it. The two successive upper limits in $o_*(1)$ therefore leave a contradiction for every sufficiently large fixed $d$ and then every sufficiently large $X$.

Finally a real principal root must satisfy $c_1\le C d\log d$ on any sequence, by the preceding contradiction (a larger $c_1$ would give the forbidden strict root inequality). By (4), $\sum c_i-1\le C d\log d+d-2$. The nonreal alternative gives at most $2d-3$. For any exponent strictly above $C d\log d+d-2$ the endpoint contradiction and factorization argument of Section 7 now apply. This proves (2) with the supremum definition of $\omega_d$.

## References

[1] Yu. Nesterenko and M. Waldschmidt. *On the approximation of the values of exponential function and logarithm by algebraic numbers*. Mat. Zapiski **2**, Diophantine Approximations (1996), 23–42. English preprint (2000), Lemma 2 and Theorem 2. [Full text](https://arxiv.org/pdf/math/0002047).

[2] Yu. M. Alexencev. *On the measure of approximation of $\pi$ by algebraic numbers*. Mathematical Notes **66** (1999), 395–403. [Journal record](https://www.mathnet.ru/eng/mzm1191).

[3] NIST Digital Library of Mathematical Functions, §27.12, *Asymptotic Formulas: Primes*. [Prime number theorem](https://dlmf.nist.gov/27.12).

[4] NIST Digital Library of Mathematical Functions, §5.11, *Asymptotic Expansions*. [Stirling expansion](https://dlmf.nist.gov/5.11.E1).

[5] NIST Digital Library of Mathematical Functions, §18.5, *Explicit Representations*. [Chebyshev trigonometric formula](https://dlmf.nist.gov/18.5.E1).
