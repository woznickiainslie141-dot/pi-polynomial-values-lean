"""Rational, outward enclosures. Arguments are exact fractions."""

from fractions import Fraction as F
from math import ceil, floor

PRECISION = 10**12


def outward(lo, hi, scale=PRECISION):
    return F(floor(lo * scale), scale), F(ceil(hi * scale), scale)


def log_unit(x):
    """Atanh series for 1 <= x <= 2, with its geometric remainder."""
    assert 1 <= x <= 2
    t = (x - 1) / (x + 1)
    count = 24
    s = 2 * sum(t ** (2 * j + 1) / (2 * j + 1) for j in range(count))
    rem = 2 * t ** (2 * count + 1) / ((2 * count + 1) * (1 - t * t))
    return s, s + rem


def log_interval(x):
    x = F(x)
    assert x > 0
    if x < 1:
        lo, hi = log_interval(1 / x)
        return -hi, -lo
    k = 0
    while x > 2:
        x /= 2
        k += 1
    lo, hi = log_unit(x)
    a, b = log_unit(F(2))
    return outward(lo + k * a, hi + k * b)


def small_atan_interval(x):
    assert 0 < x < 1
    n = 18
    s = sum((-1) ** j * x ** (2 * j + 1) / (2 * j + 1) for j in range(n))
    return outward(s, s + x ** (2 * n + 1) / (2 * n + 1))


def pi_interval():
    a, b = small_atan_interval(F(1, 5))
    c, d = small_atan_interval(F(1, 239))
    return 16 * a - 4 * d, 16 * b - 4 * c


def atan_interval(x):
    if x > 1:
        p, q = pi_interval()
        a, b = atan_interval(1 / x)
        return outward(p / 2 - b, q / 2 - a)
    if x > F(1, 2):
        p, q = pi_interval()
        a, b = atan_interval((1 - x) / (1 + x))
        return outward(p / 4 - b, q / 4 - a)
    count = 32
    total = sum((-1) ** j * x ** (2 * j + 1) / (2 * j + 1) for j in range(count))
    return outward(total, total + x ** (2 * count + 1) / (2 * count + 1))
