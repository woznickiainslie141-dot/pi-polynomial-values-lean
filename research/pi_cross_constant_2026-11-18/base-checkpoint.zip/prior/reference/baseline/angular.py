"""Folded Poisson integrals and the single-resultant criterion."""

from fractions import Fraction as F
from functools import lru_cache
from intervals import pi_interval, atan_interval, log_interval, outward


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def neg(a):
    return -a[1], -a[0]


def scale(a, q):
    return (a[0] * q, a[1] * q) if q >= 0 else (a[1] * q, a[0] * q)


def rounded(a):
    return [str(x) for x in outward(*a, 10**10)]


@lru_cache(None)
def integrals(z, y):
    if not y:
        return (F(0), F(0)), (F(0), F(0))
    p0, p1 = pi_interval()
    c = (1 - y * y) / (1 + y * y)
    r = (1 + z) / (1 - z)
    A = add(atan_interval(r * y), atan_interval(y / r))
    weights = (2 * A[0] / p1, 2 * A[1] / p0) if y < 1 else (F(1), F(1))
    val = 2 * log_interval(r)[0], 2 * log_interval(r)[1]
    J = add(val, neg(log_interval((1 + z * z + 2 * z * c) / (1 + z * z - 2 * z * c))))
    assert J[0] >= 0
    return outward(*weights, 10**15), outward(
        J[0] * (1 - z * z) / (2 * z * p1), J[1] * (1 - z * z) / (2 * z * p0), 10**15
    )


def verify(case, shape, discovery, parameters):
    d = case["d"]
    L = F(case["L"])
    Q = F(case["Q"])
    m = list(map(F, case["sorted_positive_moments"]))
    b, C = map(F, parameters)
    z = F(str(discovery["z"]))
    count = discovery["grid"]
    unit = discovery["unit"]
    rows = {x["label"]: (list(map(F, x["k"])), F(x["upper"])) for x in case["knots"]}
    demand = [(F(0), F(0)) for _ in m]
    gain = (F(0), F(0))
    last = 0
    vector_count = 0
    for left, right, items in discovery["allocation"]:
        assert (
            left == last < right <= count
            and all(n > 0 for _, n in items)
            and sum(n for _, n in items) == unit
        )
        last = right
        w0, j0 = integrals(z, F(left, count))
        w1, j1 = integrals(z, F(right, count))
        weight = add(w1, neg(w0))
        sine = add(j1, neg(j0))
        assert min(weight[0], sine[0]) > 0
        k = [
            sum(F(n, unit) * rows[tag][0][i] for tag, n in items) for i in range(len(m))
        ]
        envelope = sum(F(n, unit) * rows[tag][1] for tag, n in items)
        scalar = 2 * sum(x * y for x, y in zip(k, m)) / L
        if any(k[i] != (i + 1) * k[0] for i in range(len(m))):
            vector_count += 1
        gain = add(gain, add(scale(sine, scalar), scale(weight, -envelope)))
        for i in range(len(m)):
            demand[i] = add(demand[i], scale(sine, k[i] - (k[i - 1] if i else 0)))
    assert last == count and vector_count > 0
    p0, p1 = pi_interval()
    A = (p0 * (1 / z - z) / 4, p1 * (1 / z - z) / 4)
    slacks = [add(A, neg(x)) for x in demand]
    assert min(x[0] for x in slacks) > 0
    boundary = add(scale(A, Q), neg(gain))
    f0 = rows["scalar-0"][1]
    sh = shape["shape"]
    D = F(sh["degree_rate_upper"][1])
    G = F(sh["prime_cost_upper"][1])
    A0 = F(shape["A0_upper"][1])
    half = list(map(F, sh["row_counts_scaled_by_total"]))
    a = half[:0:-1] + half
    s = sum(x * x for x in a) / (2 * L)
    assert L == sum(a) and A0 + G + f0 > 0
    kl, kh = log_interval(1 / z)
    B = b * kl * L / 2
    assert 2 * B / 3 < C - d + 1 < C < 2 * B
    primary = B - (2 * B - C) ** 2 / (8 * B)
    rhs = D + b * (d * (A0 + G) + (d - 1) * f0 + kh * s + boundary[1])
    loss = (2 * B - C + d - 1) / (4 * B)
    cut = (d - 1) / (b * L)
    assert 0 < cut < 1
    sec = F(1, 2) - s / L - p1 * Q / (2 * L * (1 - cut**2))
    assert primary > rhs and sec > loss, (float(primary - rhs), float(sec - loss))
    return dict(
        d=d,
        b=str(b),
        z=str(z),
        root_threshold=str(C),
        omega_upper=str(C - 1),
        angular_grid=count,
        angular_pieces=len(discovery["allocation"]),
        nonproportional_pieces=vector_count,
        direction_slacks=[rounded(x) for x in slacks],
        boundary=rounded(boundary),
        primary_lower=rounded((primary, primary)),
        right_upper=rounded((rhs, rhs)),
        margin=rounded((primary - rhs, primary - rhs)),
        loss_slope=rounded((loss, loss)),
        secondary_slope=rounded((sec, sec)),
    )
