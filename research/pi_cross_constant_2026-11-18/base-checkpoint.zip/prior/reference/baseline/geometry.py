"""Rank, degree, prime layers and frequency quantiles."""

from fractions import Fraction as F
from math import floor
from intervals import outward


def pos(x):
    return max(x, 0)


def positive_integral(left, right, x, y):
    """Integral of the positive part of the affine interpolant."""
    if max(x, y) <= 0:
        return F(0)
    if min(x, y) >= 0:
        return (right - left) * (x + y) / 2
    return (right - left) * max(x, y) ** 2 / (2 * abs(x - y))


def prime_cost(a, k, q, j, L, eta):
    average_j = 4 * sum(s * t for s, t in zip(k, j)) / L
    average_q = sum(s * t for s, t in zip(a, q)) / L
    cap = average_j - average_q

    def fac(vs):
        return sum(
            pos(v - t * eta) ** 2 / (2 * t)
            for v in vs
            for t in range(1, floor(v / eta) + 1)
        )

    base = eta * cap + (fac(a) - 4 * fac(k)) / L

    def tail(vals, offsets, r, y):
        return sum(pos(v - pos(r - t) * y) for v, t in zip(vals, offsets))

    xmax = max(max(a), max(k))
    top = max(max(q) + floor(max(a) / eta), max(j) + floor(max(k) / eta))
    extra = F(0)
    subintervals = 0
    for r in range(1, top + 1):
        cuts = {eta, xmax}
        for vals, offsets in ((a, q), (k, j)):
            for v, t in zip(vals, offsets):
                if r > t and eta < v / (r - t) < xmax:
                    cuts.add(v / (r - t))
        cuts = sorted(cuts)
        residual = [(tail(a, q, r, y) - 4 * tail(k, j, r, y)) / L for y in cuts]
        extra += sum(
            positive_integral(lo, hi, x, y)
            for lo, hi, x, y in zip(cuts, cuts[1:], residual, residual[1:])
        )
        subintervals += len(cuts) - 1
    return base - extra, extra, base, subintervals


def enc(value, precision=10**10):
    return [str(x) for x in outward(value, value, precision)]


def exact_shape(d, widths_raw, row_raw):
    widths = [F(v, 10000) for v in widths_raw]
    assert widths == sorted(widths, reverse=True) and widths[0] == 1 and widths[-1] > 0
    T, V = len(widths) - 1, len(row_raw) - 1
    L = 2 * sum(widths)
    a = [L * F(v, 2 * sum(row_raw) - row_raw[0]) for v in row_raw[:0:-1] + row_raw]
    assert sum(a) == L and min(a) > 0
    q = [0] * len(a)
    groups = []
    for residue in range(4):
        ids = sorted(
            (i for i in range(len(a)) if (i - V) % 4 == residue), key=lambda i: -a[i]
        )
        groups.append(ids)
        for grade, i in enumerate(ids):
            q[i] = grade
    slack = [
        sum(a[i] for ids in groups for i in ids[: h + 1]) - 2 * sum(widths[: h + 1])
        for h in range(T + 1)
    ]
    assert min(slack) >= 0 and slack[-1] == 0
    cap = (
        2 * sum(j * u for j, u in enumerate(widths)) - sum(v * t for v, t in zip(a, q))
    ) / L

    def cost(z):
        return (
            -1
            + (
                2 * sum(min(z, u) for u in widths)
                + sum(
                    max(0, v - 2 * z - 2 * k)
                    for v in a
                    for k in range(int(max(a) / 2) + 1)
                )
            )
            / L
        )

    D = cap - max(cost(z) for z in [F(0), *widths])
    cutoffs = (F(1, 30), F(1, 24))
    costs = {
        str(eta): prime_cost(a, [u / 2 for u in widths], q, list(range(T + 1)), L, eta)[
            0
        ]
        for eta in cutoffs
    }
    Q = F(0)
    for v in range(1, V + 1):
        mass = sum(a[V + v :])
        for h in range(1, T + 2):
            x = (sum(widths[:h]) - mass) / h
            if (widths[h] if h < len(widths) else F(0)) <= x <= widths[h - 1]:
                break
        assert sum(max(0, u - x) for u in widths) == mass
        Q += sum(max(0, u * u - x * x) for u in widths) / L
    return dict(
        d=d,
        T=T,
        V=V,
        parameters={"u": widths_raw, "a": row_raw},
        row_counts_scaled_by_total=list(map(str, a[V:])),
        degree_rate_upper=enc(D),
        prime_cost_upper=enc(min(costs.values())),
        signed_pairing=enc(Q),
        rank_slack_at_T=str(slack[-1]),
        min_rank_slack_before_T=str(min(slack[:-1])),
        prime_cost_by_cutoff={k: enc(x) for k, x in costs.items()},
    )


def sorted_moments(masses, widths):
    positive = []
    cut = widths[0]
    V = len(masses) // 2
    for v in range(V, 0, -1):
        required = sum(masses[V + v :])
        for i in range(1, len(widths) + 1):
            lower = (sum(widths[:i]) - required) / i
            if (widths[i] if i < len(widths) else 0) <= lower <= widths[i - 1]:
                break
        assert sum(max(0, u - lower) for u in widths) == required
        positive.append(sum(max(0, min(cut, u) ** 2 - lower**2) for u in widths) / 2)
        cut = lower
    return positive[::-1]
