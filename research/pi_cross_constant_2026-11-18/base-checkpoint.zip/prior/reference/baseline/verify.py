"""Replay every finite witness used in the two manuscripts. Python 3.10+ and NumPy."""

import argparse
import json
from fractions import Fraction as F
from math import comb
from pathlib import Path

from angular import verify as verify_transfer
from energy import fields, primitives
from geometry import exact_shape, enc, sorted_moments
from intervals import log_interval, pi_interval

HERE = Path(__file__).resolve().parent


def fixed(d, first, second):
    data = json.loads((HERE / f"case{d}.json").read_text(encoding="utf-8"))
    assert data["d"] == d and (data["grid"], data["unit"]) == (256, 10**8)
    band, weights = data["shape"]["u"], data["shape"]["a"]
    shape = exact_shape(d, band, weights)
    half = list(map(F, shape["row_counts_scaled_by_total"]))
    masses = half[:0:-1] + half
    L = sum(masses)
    A = sum(a * a * (F(3, 2) - log_interval(2 * a)[0]) for a in masses) / (2 * L)
    moments = sorted_moments(masses, [F(x, 10000) for x in band])
    Q = 2 * sum(i * x for i, x in enumerate(moments, 1)) / L
    assert F(shape["signed_pairing"][0]) <= Q <= F(shape["signed_pairing"][1])
    witness = data["witness"]
    assert (witness["bins"], witness["unit"]) == (80, 100000)
    knots = fields(shape, witness, first, second)
    used = {tag for l, r, items in data["allocation"] for tag, n in items}
    assert len(knots) == len(used) and {row["label"] for row in knots} == used
    zero = next(row for row in knots if row["label"] == "scalar-0")
    assert all(F(k) == 0 for k in zero["k"])
    case = dict(
        d=d,
        L=str(L),
        Q=str(Q),
        sorted_positive_moments=list(map(str, moments)),
        knots=knots,
    )
    result = verify_transfer(
        case, dict(shape=shape, A0_upper=enc(A)), data, (data["b"], data["C"])
    )
    num = lambda k, i: F(result[k][i])
    if d == 2:
        target, gap, sec, loss = "16.1942", ".000019218", ".33327961", ".198218"
    else:
        target, gap, sec, loss = "27.4188", ".000031098", ".36322111", ".219312"
    assert F(result["omega_upper"]) == F(target)
    assert (
        num("margin", 0) > F(gap)
        and num("secondary_slope", 0) > F(sec)
        and num("loss_slope", 1) < F(loss)
    )
    assert min(F(x[0]) for x in result["direction_slacks"]) > F(".00004999")
    result.update(
        L=str(L),
        s=str(sum(t * t for t in masses) / (2 * L)),
        Q=str(Q),
        A0_upper=enc(A)[1],
        f0=zero["upper"],
        D_upper=shape["degree_rate_upper"][1],
        G_upper=shape["prime_cost_upper"][1],
        rank_slack_before_T=shape["min_rank_slack_before_T"],
        rank_slack_at_T=shape["rank_slack_at_T"],
        fields=len(knots),
    )
    if d == 2:
        printed = (
            "3.087798599",
            "2.122800317",
            ".815618183",
            ".084130974",
            "-.3573967591",
            "2.837884852",
            "12.5501790262",
            "12.5501598073",
        )
        rank, length, count, pieces = F(407, 625), F(1728, 125), 54, 57
    else:
        printed = (
            "5.628721405",
            "2.545131654",
            "1.462388866",
            ".093580139",
            "-.3468092793",
            "6.023875179",
            "21.6842515238",
            "21.6842204255",
        )
        rank, length, count, pieces = F(48, 125), F(30227, 1250), 50, 55
    values = list(map(F, printed))
    for key, upper in zip(
        ("D_upper", "G_upper", "Q", "A0_upper", "f0"), values[:5], strict=True
    ):
        assert F(result[key]) <= upper
    assert (
        num("boundary", 1) <= values[5]
        and num("primary_lower", 0) >= values[6]
        and num("right_upper", 1) <= values[7]
    )
    assert (
        F(result["rank_slack_before_T"]) == rank and F(result["rank_slack_at_T"]) == 0
    )
    assert L == length and len(knots) == count and len(data["allocation"]) == pieces
    return result


def large_degree():
    a, b, c, s, C = F(33, 8), F(3, 5), F(6, 7), F(511, 125), F(208, 25)
    z, t = F(4, 39), F(9999, 10000)
    eta = s * c / (a * b)
    halfpi, boundary, kappa = F(355, 226), F(4824, 1000), F(227726, 100000)
    assert s - b * (a / c + 2) == F(1, 2000) and eta > 1
    assert pi_interval()[1] / 2 < halfpi and log_interval(1 / z)[0] > kappa
    assert (1 - z * z) / (2 * z) + (1 / z + t * z) * (1 - t) / (4 * t) < boundary
    v = halfpi * boundary * b * c
    cost = a / 2 + s / 2 - b / 4 - a * b / (4 * s)
    powers = [C - cost, -C - v, kappa * a * b + v * (1 + 1 / eta) / 2, -v / (3 * eta)]
    low = None
    width = F(1, 128)
    for h in range(128):
        left = h * width
        local = [
            sum(
                powers[k] * comb(k, j) * left ** (k - j) * width**j for k in range(j, 4)
            )
            for j in range(4)
        ]
        coeff = [
            sum(local[j] * F(comb(i, j), comb(3, j)) for j in range(i + 1))
            for i in range(4)
        ]
        low = min(coeff) if low is None else min(low, *coeff)
    assert low == F(40243808891539, 22705471488000000) > F(1, 1000)
    return dict(coefficient=str(C), bernstein_entries=512, lower=str(low))


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions to execute the checks.")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--json", type=Path, help="write the computed rational enclosures to this file"
    )
    args = p.parse_args()
    one, two = primitives()
    report = dict(
        fixed_degrees=[fixed(d, one, two) for d in (2, 3)], large_degree=large_degree()
    )
    for item in report["fixed_degrees"]:
        print(
            "d =",
            item["d"],
            "w =",
            item["omega_upper"],
            "strict gap >=",
            item["margin"][0],
        )
    print("Large degrees, coefficient =", report["large_degree"]["coefficient"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
