"""Integer enclosures for the two primitives and the spatial energy dual."""

from fractions import Fraction as F
import numpy as np
from intervals import outward

DEN = 10000
FIRST_SCALE = 10**9
SECOND_SCALE = 10**12
LOG_SCALE = 10**23


def primitives():
    # Accumulate log(k+1)-log(k)=2*atanh(1/(2k+1)) with integer lower/upper sums.
    logs = [(0, 0), (0, 0)]
    for k in range(1, 2 * DEN):
        w = 2 * k + 1
        power = w
        l, h = logs[-1]
        degree = 1
        while (a := (2 * LOG_SCALE) // (degree * power)) > 0:
            l += a
            h += a + 1
            degree += 2
            power *= w * w
        logs.append((l, h + 2))
    one = [0]
    two = [0]
    for k in range(1, 2 * DEN + 1):
        lo = logs[k][0] + logs[2][0] - logs[DEN][1]
        hi = logs[k][1] + logs[2][1] - logs[DEN][0]
        f1 = (k * FIRST_SCALE * (lo - LOG_SCALE)) // (DEN * LOG_SCALE)
        f2 = (k * k * SECOND_SCALE * (2 * lo - 3 * LOG_SCALE)) // (
            4 * DEN * DEN * LOG_SCALE
        )
        assert (f1 + 2) * DEN * LOG_SCALE >= k * FIRST_SCALE * (hi - LOG_SCALE)
        assert (f2 + 2) * 4 * DEN * DEN * LOG_SCALE >= k * k * SECOND_SCALE * (
            2 * hi - 3 * LOG_SCALE
        )
        one.append(f1)
        two.append(f2)
    return np.array([-x for x in one[:0:-1]] + one, dtype=np.int64), np.array(
        two, dtype=np.int64
    )


def fields(shape, witness, one, two):
    V = shape["V"]
    half = list(map(F, shape["row_counts_scaled_by_total"]))
    a = half[:0:-1] + half
    L = sum(a)
    widths = shape["parameters"]["u"]
    bins, unit = witness["bins"], witness["unit"]
    assert (2 * DEN) % bins == 0 and L == F(2 * sum(widths), DEN)
    edges = np.arange(-DEN, DEN + 1, 2 * DEN // bins, dtype=np.int64)
    x = np.arange(DEN + 1, dtype=np.int64)
    basis = one[2 * DEN + x[:, None] - edges]
    left, right = edges[:-1], edges[1:]
    J = (
        two[abs(right[:, None] - left)]
        - two[abs(left[:, None] - left)]
        - two[abs(right[:, None] - right)]
        + two[abs(left[:, None] - right)]
    )
    weights = np.count_nonzero(np.arange(1, DEN + 1)[:, None] <= widths, axis=1)
    integral_error = F(5 + (2 * DEN).bit_length(), 4 * DEN**2)
    out = []
    for row in witness["knots"]:
        positive = np.array(row["density"], dtype=np.int64)
        assert (
            positive.shape == (V + 1, bins) and (positive[0] == positive[0, ::-1]).all()
        )
        rho = np.r_[positive[:0:-1, ::-1], positive]
        b = row["b"][:0:-1] + row["b"]
        k = np.array(row["field"], dtype=np.int64)
        assert k.shape == (V + 1,) and k[0] == 0
        full_k = np.r_[-k[:0:-1], k]
        jumps = np.diff(np.pad(rho, ((0, 0), (1, 1))), axis=1)
        l1 = np.abs(jumps).sum(axis=1)
        assert (jumps.sum(axis=1) == 0).all()
        maxint = (int(np.abs(basis).max()) + 2) * int(l1.max()) + (
            max(map(abs, b)) + int(np.abs(k).max())
        ) * FIRST_SCALE
        assert 2 * maxint < 2**63
        field = (
            basis @ jumps.T
            + (FIRST_SCALE // DEN) * x[:, None] * full_k
            - np.array(b) * FIRST_SCALE
            + 2 * l1
        )
        env = field.max(axis=1)
        integral = F(
            sum(int(w) * (int(l) + int(h)) for w, l, h in zip(weights, env, env[1:])),
            DEN * FIRST_SCALE * unit,
        )
        integral += (
            F(len(widths) * int(np.abs(jumps).max(axis=0).sum()), unit) * integral_error
        )
        q = 0
        for density in rho:
            norm = int(np.abs(density).sum())
            assert int(np.abs(J).max()) * norm < 2**63
            q += 8 * norm**2 - sum(
                int(x) * int(y) for x, y in zip(density, J @ density)
            )
        raw = (
            integral
            + F(q, 2 * SECOND_SCALE * unit**2)
            + sum(m * bv for m, bv in zip(a, b)) / unit
        ) / L
        out.append(
            dict(
                label=row["label"],
                k=list(map(str, [F(int(x), unit) for x in k[1:]])),
                upper=str(outward(raw, raw, 10**10)[1]),
            )
        )
    return out
