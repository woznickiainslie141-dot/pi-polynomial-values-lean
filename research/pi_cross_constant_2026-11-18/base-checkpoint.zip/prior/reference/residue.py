"""Exact prime-window integrals for the Vandermonde denominator bound."""

from fractions import Fraction as F
from itertools import combinations
from math import ceil, floor


def balanced_excess(difference, nodes):
    quotient, remainder = divmod(difference, nodes)
    return nodes * quotient * (quotient - 1) // 2 + remainder * quotient


def value(line, y):
    intercept, slope = line
    return intercept + slope * y


def residue_window(widths, masses, lo, hi):
    """Integrate 2*excess/L over lo<y<hi, 0<x<y/2."""
    assert 0 < lo < hi
    bottom = (F(0), F(0))
    top = (F(0), F(1, 2))
    lines = {bottom, top}
    bound = ceil(max(widths) / lo) + 2
    for width in widths:
        for intercept in (width, -width):
            for slope in range(-bound, bound + 1):
                line = (intercept, F(slope))
                if max(value(line, y) for y in (lo, hi)) <= 0:
                    continue
                if min(value(line, y) - y / 2 for y in (lo, hi)) >= 0:
                    continue
                lines.add(line)
    cuts = {lo, hi}
    for a in masses:
        for k in range(1, floor(a / lo) + 1):
            if lo < a / k < hi:
                cuts.add(a / k)
    for (a, b), (c, d) in combinations(lines, 2):
        if b != d:
            y = (c - a) / (b - d)
            if lo < y < hi and 0 <= a + b * y <= y / 2:
                cuts.add(y)

    cuts = sorted(cuts)
    integral = F(0)
    half_area = F(0)
    positive_cells = 0
    cells = 0
    largest = 0
    for left, right in zip(cuts, cuts[1:]):
        y = (left + right) / 2
        ordered = sorted((line for line in lines if 0 <= value(line, y) <= y / 2),
                         key=lambda line: value(line, y))
        assert ordered[0] == bottom and ordered[-1] == top
        H = sum(floor(a / y) for a in masses)
        for lower, upper in zip(ordered, ordered[1:]):
            x = (value(lower, y) + value(upper, y)) / 2
            columns = sum(1 + floor((u - x) / y) + floor((u + x) / y)
                          for u in widths)
            excess = balanced_excess(columns - H, len(masses))
            assert excess >= 0
            left_width = value(upper, left) - value(lower, left)
            right_width = value(upper, right) - value(lower, right)
            assert min(left_width, right_width) >= 0
            area = (right - left) * (left_width + right_width) / 2
            half_area += area
            integral += area * excess
            positive_cells += int(excess > 0)
            largest = max(largest, excess)
            cells += 1
    assert half_area == (hi * hi - lo * lo) / 4
    return dict(lo=str(lo), hi=str(hi), strips=len(cuts)-1, cells=cells,
                positive_cells=positive_cells, largest_excess=largest,
                saving=str(2 * integral / sum(masses)))


def check_old_cap(widths, masses, ranks, lo, hi):
    """Check R_h >= C_h on a window for both cutoffs used in the baseline."""
    lo = max(lo, F(1, 30))
    if lo >= hi:
        return
    columns = [u/2 for u in widths]
    grades = list(range(len(widths)))
    max_h = max(max(ranks) + floor(max(masses) / lo),
                max(grades) + floor(max(columns) / lo)) + 1
    for h in range(1, max_h + 1):
        row_shifts = [max(0, h - q) for q in ranks]
        col_shifts = [max(0, h - j) for j in grades]
        cuts = {lo, hi}
        for length, shift in [*zip(masses, row_shifts), *zip(columns, col_shifts)]:
            if shift and lo < length / shift < hi:
                cuts.add(length / shift)
        for y in cuts:
            row_tail = sum(max(0, a - k*y) for a, k in zip(masses, row_shifts))
            col_tail = 4 * sum(max(0, b - k*y) for b, k in zip(columns, col_shifts))
            assert row_tail >= col_tail, (h, y)


def certificate(widths, masses, raw_windows):
    V = len(masses) // 2
    ranks = [0] * len(masses)
    for residue in range(4):
        ids = [i for i in range(len(masses)) if (i - V) % 4 == residue]
        for q, i in enumerate(sorted(ids, key=lambda i: -masses[i])):
            ranks[i] = q
    L = sum(masses)
    cap = (2 * sum(j*u for j, u in enumerate(widths))
           - sum(q*a for q, a in zip(ranks, masses))) / L
    windows = []
    previous = F(0)
    for raw_lo, raw_hi in raw_windows:
        lo, hi = F(raw_lo), F(raw_hi)
        assert previous <= lo < hi
        check_old_cap(widths, masses, ranks, lo, hi)
        box = residue_window(widths, masses, lo, hi)
        assert F(box["saving"]) > 0
        # Even the largest residue penalty on this window leaves a nonnegative
        # allowed denominator exponent. This also covers replacing a local
        # valuation by its nonnegative denominator part.
        assert cap > hi * box["largest_excess"] / L
        previous = hi
        windows.append(box)
    return sum((F(box["saving"]) for box in windows), F(0)), windows
