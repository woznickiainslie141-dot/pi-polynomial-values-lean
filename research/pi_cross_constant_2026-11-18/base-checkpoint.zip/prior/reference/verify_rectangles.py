"""Independent standard-library lower sums for the new prime savings and resultant gaps."""

import argparse
import json
from fractions import Fraction as F
from math import ceil, floor
from pathlib import Path

HERE = Path(__file__).resolve().parent


def residue_counts(widths, y):
    # Counts at the left-hand open interval in 0 < tau < 1/2, then jumps.
    initial = 0
    jumps = {}
    for width in widths:
        ratio = width/y
        initial += ceil(ratio) + floor(ratio)
        remainder = ratio - floor(ratio)
        for point, change in ((remainder, -1), (1-remainder, 1)):
            if 0 < point < F(1, 2):
                jumps[point] = jumps.get(point, 0) + change
    return initial, jumps


def minimum_cost(first, last, nodes):
    assert first <= last
    if last >= 0 and first <= nodes:
        return 0
    # The cell touches the increasing right branch or the decreasing left
    # branch. On the left use Phi(s)=Phi(nodes-s).
    distance = first-nodes if first > nodes else -last
    quotient, rest = divmod(distance, nodes)
    return nodes*quotient*(quotient+1)//2 + rest*(quotient+1)


def lower_sum(widths, masses, windows, subdivisions):
    answer = F(0)
    for start, end in windows:
        start, end = F(start), F(end)
        step = (end-start)/subdivisions
        for k in range(subdivisions):
            lo, hi = start+k*step, start+(k+1)*step
            h_max = sum(floor(a/lo) for a in masses)
            h_min = sum(floor(a/hi) for a in masses)
            c_max, jump_max = residue_counts(widths, lo)
            c_min, jump_min = residue_counts(widths, hi)
            left, weight = F(0), F(0)
            for right in sorted({*jump_min, *jump_max, F(1, 2)}):
                cost = minimum_cost(c_min-h_max, c_max-h_min, len(masses))
                weight += (right-left)*cost
                c_min += jump_min.get(right, 0)
                c_max += jump_max.get(right, 0)
                left = right
            answer += (hi*hi-lo*lo)*weight
    return answer/sum(masses)


def check(subdivisions, record_path):
    published = json.loads(record_path.read_text(encoding="utf-8"))
    report = []
    for row in published["cases"]:
        record = row["improved"]
        d = record["d"]
        case = json.loads((HERE/f"case{d}.json").read_text(encoding="utf-8"))
        widths = [F(x,10000) for x in case["shape"]["u"]]
        ratios = case["shape"]["a"]
        ratios = ratios[:0:-1] + ratios
        L = 2*sum(widths)
        masses = [L*t/sum(ratios) for t in ratios]
        s = sum(t*t for t in masses)/(2*L)
        assert L == F(record["L"]) and s == F(record["s"])
        gain = lower_sum(widths, masses, case["prime_windows"], subdivisions)
        # This second gap only uses the rectangular lower sum. The first
        # verifier's full polygon integral is compared after computing it.
        b, C = F(case["b"]), F(case["C"])
        kl, kh = map(F, record["kappa"])
        B = b*L*kl/2
        assert 2*B/3 < C-d+1 < C < 2*B
        lhs = C/2+B/2-C*C/(8*B)
        rhs = F(record["D_upper"]) + b*(
            d*(F(record["A0_upper"])+F(record["G_before"])-gain)
            + (d-1)*F(record["f0_upper"])+s*kh+F(record["boundary_upper"]))
        gap = lhs-rhs
        assert 0 < gain <= F(record["prime_saving"]) and gap > 0
        assert F(record["secondary_lower"]) > F(record["loss_upper"])
        assert min(map(F,record["direction_slack_lower"])) > 0
        grid = 10**12
        result = dict(d=d, subdivisions_per_window=subdivisions,
                      saving_lower=str(F(floor(gain*grid),grid)),
                      margin_lower=str(F(floor(gap*grid),grid)))
        assert F(result["margin_lower"]) > 0
        report.append(result)
        print(f"d={d}  saving>={result['saving_lower']}  margin>={result['margin_lower']}")
    return report


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("The verifier requires assertions. Run Python without -O.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, default=HERE/"certificate.json",
                        help="directed constants produced by verify.py")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    result = check(256, args.certificate)
    if args.json:
        args.json.write_text(json.dumps(dict(status="passed",cases=result),indent=2)+"\n",
                             encoding="utf-8")
