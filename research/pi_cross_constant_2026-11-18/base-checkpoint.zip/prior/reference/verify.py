"""Recompute the old thresholds and the new low-degree certificates from raw data."""

import argparse
import json
import sys
from fractions import Fraction as F
from math import floor
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "baseline"))
from angular import integrals
from energy import fields, primitives
from geometry import enc, exact_shape, sorted_moments
from intervals import log_interval, outward, pi_interval
from residue import certificate


def pair(lo, hi, scale=10**10):
    return [str(x) for x in outward(lo, hi, scale)]


def product(bounds, coefficient):
    lo, hi = bounds
    return (lo*coefficient, hi*coefficient) if coefficient >= 0 else (hi*coefficient, lo*coefficient)


def angular_upper(data, nodes, moments, L, Q):
    knots = {row["label"]: (list(map(F, row["k"])), F(row["upper"])) for row in nodes}
    assert len(nodes) == len(knots) and all(not k for k in knots["scalar-0"][0])
    z = F(str(data["z"]))
    grid, unit = data["grid"], data["unit"]
    assert isinstance(grid, int) and grid > 0 and isinstance(unit, int) and unit > 0
    gain_lo = F(0)
    costs_hi = [F(0)] * len(moments)
    left = 0
    used = set()
    for start, end, mix in data["allocation"]:
        assert start == left < end <= grid
        assert all(isinstance(n, int) and n > 0 for _, n in mix)
        assert sum(n for _, n in mix) == unit
        used.update(tag for tag, _ in mix)
        w0, j0 = integrals(z, F(start, grid))
        w1, j1 = integrals(z, F(end, grid))
        w = w1[0]-w0[1], w1[1]-w0[0]
        j = j1[0]-j0[1], j1[1]-j0[0]
        assert w[0] > 0 and j[0] > 0
        k = [sum(F(n, unit)*knots[tag][0][i] for tag, n in mix)
             for i in range(len(moments))]
        envelope = sum(F(n, unit)*knots[tag][1] for tag, n in mix)
        moment = 2*sum(v*m for v, m in zip(k, moments, strict=True))/L
        gain_lo += product(j, moment)[0] + product(w, -envelope)[0]
        for i, (p, q) in enumerate(zip([F(0)] + k, k)):
            costs_hi[i] += product(j, q-p)[1]
        left = end
    assert left == grid and used | {"scalar-0"} == set(knots)
    pi_lo, pi_hi = pi_interval()
    scale = (1/z-z)/4
    slacks = [pi_lo*scale - expense for expense in costs_hi]
    assert min(slacks) > 0
    return pi_hi*scale*Q - gain_lo, knots["scalar-0"][1], slacks


def threshold(D, K, A):
    """Isolate the exact threshold for fixed directed constants, allowing any b."""
    quadratic = lambda p: K*((1-p)**2+p*p) - A
    assert quadratic(F(0)) > 0 > quadratic(F(1, 3))
    resolution = 10**8
    # The smaller root p is in (0,1/3), and the threshold is D/p.
    left = max(1, floor(3*D*resolution))
    right = left*2
    while quadratic(D*resolution/right) <= 0:
        right *= 2
    while right-left > 1:
        mid = (left+right)//2
        if quadratic(D*resolution/mid) > 0:
            right = mid
        else:
            left = mid
    lo, hi = F(left, resolution), F(right, resolution)
    assert quadratic(D/lo) < 0 < quadratic(D/hi)
    return lo, hi


def check(data, meshes):
    d = data["d"]
    assert d in (2, 3)
    u, a = data["shape"]["u"], data["shape"]["a"]
    assert all(type(t) is int and t > 0 for t in u+a)
    sh = exact_shape(d, u, a)
    half = list(map(F, sh["row_counts_scaled_by_total"]))
    masses = half[:0:-1] + half
    widths = [F(t, 10000) for t in u]
    L = sum(masses)
    assert L == 2*sum(widths)
    s = sum(a*a for a in masses)/(2*L)
    A0 = F(enc(sum(a*a*(F(3, 2)-log_interval(2*a)[0]) for a in masses)/(2*L))[1])
    moments = sorted_moments(masses, widths)
    Q = 2*sum(i*x for i, x in enumerate(moments, 1))/L
    assert F(sh["signed_pairing"][0]) <= Q <= F(sh["signed_pairing"][1])
    wit = data["witness"]
    assert wit["unit"] == 100000 and wit["bins"] == 80
    for row in wit["knots"]:
        assert len(row["b"]) == len(row["field"]) == len(half)
        for line in [row["b"], row["field"], *row["density"]]:
            assert all(type(v) is int and abs(v) < 10**8 for v in line)
    knots = fields(sh, wit, *meshes)
    boundary, f0, slacks = angular_upper(data, knots, moments, L, Q)
    D = F(sh["degree_rate_upper"][1])
    old_G = F(sh["prime_cost_upper"][1])
    saving, windows = certificate(widths, masses, data.get("prime_windows", []))
    G = old_G - saving
    b, C, z = (F(str(data[k])) for k in ("b", "C", "z"))
    assert b > 0 and C > d+1 and 0 < z < 1
    kl, kh = log_interval(1/z)
    K = L*kl/2
    B = b*K
    A = d*(A0+G) + (d-1)*f0 + s*kh + boundary
    g = A0 + G + f0
    assert g > 0 and 2*B/3 < C-d+1 < C < 2*B
    p = (2*B-C)/(4*B)
    lhs = B - (2*B-C)**2/(8*B)
    assert lhs == C*p+B*((1-p)**2+p*p)
    rhs = D+b*A
    h = (d-1)/(b*L)
    assert 0 < h < 1
    secondary = F(1, 2)-s/L-pi_interval()[1]*Q/(2*L*(1-h*h))
    loss = (2*B-C+d-1)/(4*B)
    assert secondary > loss and lhs > rhs
    c_lo, c_hi = threshold(D, K, A)
    assert c_hi < C
    without = threshold(D, K, A+d*saving)
    return dict(d=d, b=str(b), z=str(z), C=str(C), w=str(C-1), L=str(L), s=str(s),
                Q=str(Q), A0_upper=str(A0), f0_upper=str(f0), D_upper=str(D),
                G_before=str(old_G), prime_windows=windows, prime_saving=str(saving),
                G_upper=pair(G,G)[1], G_upper_exact=str(G), field_count=len(knots),
                angular_pieces=len(data["allocation"]), angular_grid=data["grid"],
                rank_before_T=sh["min_rank_slack_before_T"], rank_at_T=sh["rank_slack_at_T"],
                direction_slack_lower=[pair(x,x)[0] for x in slacks],
                boundary_upper=pair(boundary,boundary)[1], kappa=[str(kl),str(kh)],
                B=pair(B,B), g=pair(g,g), h_star=pair(h,h), perturbation_share=pair(p,p),
                lhs_lower=pair(lhs,lhs)[0], rhs_upper=pair(rhs,rhs)[1],
                strict_margin=pair(lhs-rhs,lhs-rhs), secondary_lower=pair(secondary,secondary)[0],
                loss_upper=pair(loss,loss)[1], frozen_C=list(map(str,(c_lo,c_hi))),
                frozen_C_without_new_prime_saving=list(map(str,without)))


def main():
    if not __debug__:
        raise RuntimeError("The verifier requires assertions. Run Python without -O.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    meshes = primitives()
    report = []
    for d in (2, 3):
        def read_case(folder):
            return json.loads((folder/f"case{d}.json").read_text(encoding="utf-8"))
        old = check(read_case(HERE/"baseline"), meshes)
        new = check(read_case(HERE), meshes)
        assert F(old["w"]) == {2: F("16.1942"), 3: F("27.4188")}[d]
        assert F(new["w"]) == {2: F("16.17137"), 3: F("27.417936")}[d]
        assert F(new["C"]) < F(old["frozen_C"][0])
        assert F(new["prime_saving"]) > 0
        assert F(new["frozen_C"][1]) < F(new["C"]) < F(new["frozen_C_without_new_prime_saving"][0])
        improvement = F(old["w"])-F(new["w"])
        report.append(dict(baseline=old, improved=new, exponent_decrease=str(improvement)))
        print(f"d={d}  w={new['w']}  decrease={improvement}  margin>={new['strict_margin'][0]}")
    if args.json:
        args.json.write_text(json.dumps(dict(status="passed",cases=report), indent=2)+"\n",
                             encoding="utf-8")


if __name__ == "__main__":
    main()
