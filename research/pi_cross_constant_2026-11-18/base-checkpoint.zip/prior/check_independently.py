"""Independent scalar prime sums and endpoint checks using the Python standard library."""
import argparse
import json
import sys
from fractions import Fraction as F
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE/"reference"))
from residue import certificate as old_polygons, check_old_cap
sys.path.insert(0,str(HERE/"reference"/"baseline"))
from intervals import pi_interval


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def elementary(x,m):
    # Equivalent to repeatedly adding the forward integer slope floor(k/m).
    if 0<=x<=m:
        return 0
    if x<0:
        x=m-x
    k=x//m
    return k*x-m*k*(k+1)//2


def positive_or_negative(i, mesh, widths, H, M, upper_tail):
    den=10000*mesh
    base=0
    changes={}
    for u in widths:
        n,r=divmod(i*u,den)
        base+=2*n+int(bool(r))
        if 0 < 2*r < den:
            changes[r]=changes.get(r,0)-1
        if den < 2*r < 2*den:
            t=den-r
            changes[t]=changes.get(t,0)+1
    changes[den//2]=0
    last=0
    total=0
    for t in sorted(changes):
        x=base-H
        if (upper_tail and x>M) or (not upper_tail and x<0):
            total+=(t-last)*elementary(x,M)
        base+=changes[t]
        last=t
    return total


def lower_prime(data):
    u=data["shape"]["u"]
    widths=[F(x,10000) for x in u]
    ratios=data["shape"]["a"]; ratios=ratios[:0:-1]+ratios
    L=2*sum(widths)
    a=[L*v/sum(ratios) for v in ratios]
    V=len(ratios)//2; M=len(a)
    q=[0]*M
    for r in range(4):
        ids=sorted((i for i in range(M) if (i-V)%4==r),key=lambda i:-a[i])
        for k,i in enumerate(ids):
            q[i]=k
    start=5 if data["d"]==2 else 8
    check_old_cap(widths,a,q,F(1,30),F(1,start))
    cap=(2*sum(i*w for i,w in enumerate(widths))-sum(m*x for m,x in zip(a,q)))/L
    assert cap>F(elementary(-len(u),M),start)/L
    outer=[v for v in data["prime_windows"] if F(v[0])>=F(1,start)]
    total=old_polygons(widths,a,outer)[0]
    # A shorter finite t range and an independently evaluated scalar sum.
    pieces=[(start,40,4096),(40,128,1024),(128,512,256),(512,1024,64)]
    scale=10**19
    for left,right,mesh in pieces:
        rdata=[(x.numerator,x.denominator*mesh) for x in a]
        def rows(i):
            return sum(i*p//q for p,q in rdata)
        row0=rows(left*mesh)
        numerator=0
        for i in range(left*mesh,right*mesh):
            row1=rows(i+1)
            # Monotonicity in t. Each tail uses just one frequency endpoint.
            val=positive_or_negative(i,mesh,u,row1,M,True)
            val+=positive_or_negative(i+1,mesh,u,row0,M,False)
            if val:
                num=val*mesh*(2*i+1)*scale*L.denominator
                den=10000*L.numerator*(i*(i+1))**2
                numerator+=num//den
            row0=row1
        total+=F(numerator,scale)
    return total


def endpoint(data,prime,spec,fine,target):
    from angular import integrals
    from geometry import exact_shape, sorted_moments
    from intervals import log_interval
    from scalar_spatial import all_bounds
    d=data["d"]; C,b=F(target["C"]),F(target["b"])
    sh=exact_shape(d,data["shape"]["u"],data["shape"]["a"])
    G=F(sh["prime_cost_upper"][1])-prime
    D=F(sh["degree_rate_upper"][1])
    widths=[F(v,10000) for v in data["shape"]["u"]]
    half=list(map(F,sh["row_counts_scaled_by_total"]))
    a=half[:0:-1]+half;L=sum(a)
    assert L==2*sum(widths)
    s=sum(v*v for v in a)/(2*L)
    A0=sum(v*v*(F(3,2)-log_interval(2*v)[0]) for v in a)/(2*L)
    m=sorted_moments(a,widths)
    Q=2*sum(v*x for v,x in enumerate(m,1))/L
    pure,penalized=all_bounds(data,fine,spec)
    f0=pure["scalar-0"];assert A0+G+f0>0
    z=F(str(data["z"])); kl,kh=log_interval(1/z)
    B=b*kl*L/2
    angles=F(0);Lambda=F(0);expense=[F(0)]*len(m)
    keys={r["label"]:[F(x,data["witness"]["unit"]) for x in r["field"]]
          for r in data["witness"]["knots"]}
    def up(x,l,h):
        return x*(h if x>=0 else l)
    prev_end=0
    for begin,end,mix in data["allocation"]:
        assert begin==prev_end<end<=data["grid"]
        prev_end=end
        w0,j0=integrals(z,F(begin,data["grid"]))
        w1,j1=integrals(z,F(end,data["grid"]))
        wl,wh=w1[0]-w0[1],w1[1]-w0[0];jl,jh=j1[0]-j0[1],j1[1]-j0[0]
        assert wl>0 and jl>0 and sum(n for _,n in mix)==data["unit"]
        for tag,part in mix:
            assert type(part) is int and part>0
            scale=F(part,data["unit"])
            lam=F(spec["price"].get(tag,0),10**7)
            Lambda+=scale*wl*lam/2
            k=keys[tag];assert k[0]==0
            msum=2*sum(v*x for v,x in zip(k[1:],m))/L
            angles+=scale*(up((pure[tag]+penalized[tag])/2,wl,wh)+up(-msum,jl,jh))
            for t,(v,w) in enumerate(zip(k,k[1:])):
                expense[t]+=scale*up(w-v,jl,jh)
    assert prev_end==data["grid"]
    plo,phi=pi_interval()
    assert all(plo*(1/z-z)/4>v for v in expense)
    boundary=angles+Q*phi*(1/z-z)/4
    dlt=b*Lambda
    def minimum(c):
        offsets=[F(0)]+[q*c+dlt for q in range(1,len(data["shape"]["u"]))]
        # Projection onto the simplex by solving the Lagrange multiplier on its active face.
        for n in range(1,len(offsets)+1):
            level=(2*B+sum(offsets[:n]))/n
            if n==len(offsets) or level<=offsets[n]:
                weights=[(level-x)/(2*B) for x in offsets[:n]]
                assert min(weights)>=0 and sum(weights)==1
                return sum(x*p+B*p*p for x,p in zip(offsets,weights)),sum(i*p for i,p in enumerate(weights))
        raise ArithmeticError("No simplex face.")
    root,p=minimum(C)
    _,loss=minimum(C-d+1)
    h=(d-1)/(b*L)
    slope=F(1,2)-s/L-pi_interval()[1]*Q/(2*L*(1-h*h))
    rhs=D+b*(d*(A0+G)+(d-1)*f0+kh*s+boundary)
    assert 0<h<1 and slope>loss and root>rhs,(d,float(root-rhs))
    return dict(d=d,omega=str(C-1),independent_finite_prime_saving=str(prime),
                margin_lower=str(F((root-rhs)*10**13//1,10**13)),
                secondary_minus_loss_lower=str(F((slope-loss)*10**12//1,10**12)),
                critical_share=[str(F(p*10**12//1,10**12)),str(F(p*10**12//1+1,10**12))])


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions.")
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json",type=Path)
    args=parser.parse_args()
    targets=read(HERE/"targets.json")
    out=[]
    for d in (2,3):
        data=read(HERE/"reference"/f"case{d}.json")
        prime=lower_prime(data)
        data.update(read(HERE/f"angular{d}.json"))
        row=endpoint(data,prime,read(HERE/f"center{d}.json"),read(HERE/f"spatial{d}.json"),targets[str(d)])
        out.append(row)
        print(d,"prime >=",float(prime),"margin >=",row["margin_lower"],flush=True)
    if args.json:
        args.json.write_text(json.dumps(dict(status="passed",cases=out),indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()







