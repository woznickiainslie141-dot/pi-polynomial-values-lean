"""Exact upper bounds on the energy of the fixed sum of the reference residuals."""
import sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"reference"/"baseline"))
from energy import DEN, SECOND_SCALE


def savings(data, two):
    wit = data["witness"]
    unit = wit["unit"]
    u = np.array(data["shape"]["u"],dtype=np.int64)
    L = F(2*int(u.sum()),DEN)
    edges = np.arange(-DEN,DEN+1,2*DEN//wit["bins"],dtype=np.int64)
    seams = np.unique(np.r_[edges,-u,u])
    lo, hi = seams[:-1], seams[1:]
    # 2*x is the integer numerator of twice the midpoint.
    mid = lo+hi
    index = np.searchsorted(2*edges,mid)-1
    nu = (abs(mid[:,None])<2*u).sum(axis=1)
    J = (two[abs(hi[:,None]-lo)]-two[abs(lo[:,None]-lo)]
         -two[abs(hi[:,None]-hi)]+two[abs(lo[:,None]-hi)])
    out = {}
    for row in wit["knots"]:
        positive = np.array(row["density"],dtype=np.int64)
        rho = np.r_[positive[:0:-1,::-1],positive]
        r = unit*nu-rho.sum(axis=0)[index]
        norm = sum(map(abs,map(int,r)))
        assert int(np.abs(J).max())*norm < 2**63
        quadratic = sum(int(x)*int(y) for x,y in zip(r,J@r))
        # Each of the four primitive values is known with error <= 2 units.
        upper = F(quadratic+8*norm**2,SECOND_SCALE*unit**2)
        out[row["label"]] = max(F(0),-upper)/(2*len(rho)*L)
    return out

