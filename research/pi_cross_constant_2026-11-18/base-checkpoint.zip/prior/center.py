"""Bound the effect of centering the perturbed columns before the angular estimate."""
from fractions import Fraction as F
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference" / "baseline"))
from energy import DEN, FIRST_SCALE
from angular import integrals

PRICE_UNIT = 10**7


def endpoint_fields(data, one):
    wit = data["witness"]
    edges = np.arange(-DEN, DEN+1, 2*DEN//wit["bins"], dtype=np.int64)
    x = np.arange(DEN+1, dtype=np.int64)
    basis = one[2*DEN+x[:, None]-edges]
    for row in wit["knots"]:
        rho = np.array(row["density"], dtype=np.int64)
        full_rho = np.r_[rho[:0:-1, ::-1], rho]
        jumps = np.diff(np.pad(full_rho, ((0,0), (1,1))), axis=1)
        norm = np.abs(jumps).sum(axis=1)
        k = np.array(row["field"], dtype=np.int64)
        full_k = np.r_[-k[:0:-1], k]
        beta = np.array(row["b"][:0:-1]+row["b"], dtype=np.int64)
        bound = (int(np.abs(basis).max())+2)*int(norm.max())
        bound += FIRST_SCALE*(int(np.abs(k).max())+int(np.abs(beta).max()))
        assert 4*bound < 2**63
        values = (basis@jumps.T + (FIRST_SCALE//DEN)*x[:,None]*full_k
                  - FIRST_SCALE*beta + 2*norm)
        yield row["label"], values


def angular_weights(data):
    """Bounds on the probability of each test on one conjugate half-circle."""
    unit, grid = data["unit"], data["grid"]
    z = F(str(data["z"]))
    weights = {row["label"]: [F(0),F(0)] for row in data["witness"]["knots"]}
    for start, end, mix in data["allocation"]:
        p = integrals(z,F(start,grid))[0]
        q = integrals(z,F(end,grid))[0]
        for name, n in mix:
            weights[name][0] += F(n,2*unit)*(q[0]-p[1])
            weights[name][1] += F(n,2*unit)*(q[1]-p[0])
    assert sum(w[0] for w in weights.values()) <= F(1,2) <= sum(w[1] for w in weights.values())
    return weights


def gap_array(field, anchor):
    """Twice-counted grid endpoints, with the anchor fixed separately on each cell."""
    best = field.argmax(axis=1)
    largest = field.max(axis=1)
    second = np.partition(field,-2,axis=1)[:,-2]
    gap = largest-second
    return np.r_[np.where(best[:-1] == anchor,gap[:-1],0),
                 np.where(best[1:] == anchor,gap[1:],0)]


def jet_weights(data):
    widths = data["shape"]["u"]
    w = (np.arange(1,DEN+1)[:,None] <= widths[1:]).sum(axis=1)
    return np.tile(w,2)


def anchored_bounds(data, meshes, shape, ordinary, spec, fine=None):
    """Prove a half-circle penalty times the share for all feasible allocations."""
    from energy import fields as energy_fields
    from energy_remainder import savings
    L = F(2*sum(data["shape"]["u"]),DEN)
    weights = angular_weights(data)
    unit = data["witness"]["unit"]*FIRST_SCALE
    V = len(data["shape"]["a"])-1
    assert unit % PRICE_UNIT == 0
    jet = jet_weights(data)
    if "anchor_runs" in spec:
        segments = []
        left = 0
        for right, node in spec["anchor_runs"]:
            assert type(right) is int and left < right <= DEN and type(node) is int and -V <= node <= V
            segments.extend([node+V]*(right-left))
            left = right
        assert left == DEN
        anchor = np.array(segments,dtype=np.int64)
    else:
        source = data
        if spec.get("anchor_bins")==160:
            assert fine is not None
            source = dict(data,witness=dict(unit=fine["unit"],bins=fine["bins"],knots=fine["ordinary"]))
        base = dict(endpoint_fields(source,meshes[0]))[spec["anchor"]]
        anchor = (base[:-1]+base[1:]).argmax(axis=1)
    baseline = {row["label"]: row for row in data["witness"]["knots"]}
    prices = spec["price"]
    assert prices and set(prices) <= baseline.keys()
    replacements = {row["label"]:row for row in spec.get("knots",[])}
    assert len(replacements) == len(spec.get("knots",[])) and replacements.keys() <= prices.keys()
    selected = [replacements.get(tag,baseline[tag]) for tag in prices]
    for row in selected:
        assert row["field"] == baseline[row["label"]]["field"]
        assert len(row["b"]) == V+1
        for arr in [row["b"],row["field"],*row["density"]]:
            assert all(type(i) is int and abs(i)<10**8 for i in arr)
    def evaluate(witness):
        changed = dict(data,witness=witness)
        knots = energy_fields(shape,witness,*meshes)
        corrected = savings(changed,meshes[1])
        raw = {r["label"]:F(r["upper"])-corrected[r["label"]] for r in knots}
        for tag,field in endpoint_fields(changed,meshes[0]):
            price = prices[tag]
            assert type(price) is int and 0 < price <= 10*PRICE_UNIT
            gaps = gap_array(field,anchor)
            change = np.maximum(price*(unit//PRICE_UNIT)-gaps,0)
            num = sum(int(x)*int(w) for x,w in zip(change,jet))
            extra = F(num,DEN*unit)/L
            yield tag,raw[tag]+extra,extra,raw[tag],witness["bins"]

    candidates = list(evaluate(dict(data["witness"],knots=selected)))
    if fine:
        for category in ("tilted","ordinary"):
            fine_rows = [r for r in fine[category] if r["label"] in prices]
            if fine_rows:
                candidates.extend(evaluate(dict(unit=fine["unit"],bins=fine["bins"],knots=fine_rows)))
    best = {}
    for tag,upper,extra,raw,bins in candidates:
        if tag not in best or upper<best[tag][0]:
            best[tag]=upper,extra,raw,bins
    Lambda, Delta = F(0), F(0)
    results = {}
    for tag,(upper,extra,raw,bins) in best.items():
        increment = upper-ordinary[tag]
        lower_w, upper_w = weights[tag]
        Lambda += lower_w*F(prices[tag],PRICE_UNIT)
        Delta += (upper_w if increment>=0 else lower_w)*increment
        results[tag] = dict(price=str(F(prices[tag],PRICE_UNIT)),gap_integral=str(extra),
                            reference_change=str(raw-ordinary[tag]),increment=str(increment),bins=bins)
    return Lambda, Delta, results



