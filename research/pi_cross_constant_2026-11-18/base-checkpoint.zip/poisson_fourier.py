"""Independent rational enclosures for folded Poisson integrals by their Fourier series."""
from fractions import Fraction as F
from functools import lru_cache
from math import ceil, floor

SCALE = 10**19


def enclosure(lo, hi):
    return F(floor(lo * SCALE), SCALE), F(ceil(hi * SCALE), SCALE)


@lru_cache(None)
def short_atan(x):
    assert 0 <= x <= F(1, 2)
    # An even number of alternating terms is a lower bound for x >= 0.
    power = x
    total = F(0)
    for n in range(42):
        total += (-1)**n * power / (2*n + 1)
        power *= x*x
    return enclosure(total, total + power/85)


def atan_unit(x):
    assert 0 <= x <= 1
    if x <= F(1, 2):
        return short_atan(x)
    a, b = short_atan(F(1, 2))
    c, d = short_atan((2*x - 1)/(2 + x))
    return a + c, b + d


@lru_cache(None)
def pi_interval():
    a, b = short_atan(F(1, 2))
    c, d = short_atan(F(1, 3))
    return 4*(a + c), 4*(b + d)


@lru_cache(None)
def log_near_one(x):
    assert 1 <= x <= 2
    t = (x-1)/(x+1)
    power = t
    partial = F(0)
    for k in range(26):
        partial += 2*power/(2*k+1)
        power *= t*t
    return enclosure(partial, partial + 2*power/(53*(1-t*t)))


@lru_cache(None)
def log_interval(x):
    x = F(x)
    assert x > 0
    if x < 1:
        lo, hi = log_interval(1/x)
        return -hi, -lo
    shifts = 0
    while x > 2:
        x /= 2
        shifts += 1
    a, b = log_near_one(x)
    c, d = log_near_one(F(2))
    return a+shifts*c, b+shifts*d


@lru_cache(None)
def integrals(z, y):
    assert 0 < z < 1 and 0 <= y <= 1
    if not y:
        return (F(0), F(0)), (F(0), F(0))
    plo, phi = pi_interval()
    cosine, sine = (1-y*y)/(1+y*y), 2*y/(1+y*y)
    # Folding the Poisson density into the first quadrant cancels the odd modes.
    count = 15
    c, s = [F(1)], [F(0)]
    for n in range(2*count+1):
        c.append(c[-1]*cosine-s[-1]*sine)
        s.append(s[-1]*cosine+c[-2]*sine)
    a, b = atan_unit(y)
    pure = sum(z**(2*k)*s[2*k]/k for k in range(1,count+1))
    weighted = 1-cosine + sum(
        z**(2*k)*((1-c[2*k+1])/(2*k+1) - (1-c[2*k-1])/(2*k-1))
        for k in range(1,count+1)
    )
    # The normalized integral of either 1 or sin(theta) over the arc is <= 1.
    tail = 2*z**(2*count+2)/(1-z*z)
    assert 2*a+pure >= 0 and weighted >= 0
    W = enclosure(2*(2*a+pure)/phi-tail, 2*(2*b+pure)/plo+tail)
    J = enclosure(2*weighted/phi-tail, 2*weighted/plo+tail)
    return ((F(1), F(1)) if y == 1 else W), J

