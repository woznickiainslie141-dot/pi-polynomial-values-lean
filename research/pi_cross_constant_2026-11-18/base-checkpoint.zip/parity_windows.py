"""Prime-residue savings for odd and even frequency bands at all odd large primes."""
from fractions import Fraction as F
from math import floor


def phi(n,m):
    k,r=divmod(n,m)
    return m*k*(k-1)//2+r*k


def ranks(a):
    V=len(a)//2
    result=[0]*len(a)
    for r in range(4):
        ids=[n for n in range(len(a)) if (n-V)%4==r]
        for j,n in enumerate(sorted(ids,key=lambda n:-a[n])):result[n]=j
    return result


def check_flat(classes,a,start):
    q=ranks(a);L=sum(a);jmax=len(classes[0])-1
    low,hi=F(1,30),F(1,start)
    cols=[(F(w,20000),j) for c in classes for j,w in enumerate(c) if w]
    cap=(sum(w*j for w,j in cols)-sum(w*j for w,j in zip(a,q)))/L
    assert cap>hi*phi(-2*(jmax+1),len(a))/L
    for h in range(1,2+max(max(q)+floor(max(a)/low),jmax+floor(max(w for w,j in cols)/low))):
        terms={}
        for w,j,sign in [*((w,j,1) for w,j in cols),*((w,j,-1) for w,j in zip(a,q))]:
            x=(w,max(h-j,0));terms[x]=terms.get(x,0)+sign
        breaks={low,hi,*(w/k for w,k in terms if k and low<w/k<hi)}
        assert all(sum(v*max(0,w-k*y) for (w,k),v in terms.items())<=0 for y in breaks)
    return cap


def boxes(i,mesh,first,second):
    den=10000*mesh
    count=0;events={}
    for p,band in enumerate((first,second)):
        for w in band:
            k,r=divmod(w*i+p*den,2*den)
            count+=2*k+1-p-(r==0)
            if 0<2*r<den:
                events[r]=events.get(r,0)-1
            elif 0<2*(2*den-r)<den:
                t=2*den-r;events[t]=events.get(t,0)+1
    events[den//2]=0;prev=0;out=[]
    for t in sorted(events):
        out.append((t-prev,count));count+=events[t];prev=t
    return out


def finite(d,classes,a):
    assert classes[0]==classes[2] and classes[1]==classes[3]
    L=sum(a);m=len(a);start=5 if d==2 else 8
    check_flat(classes,a,start)
    scale=10**19;value=0
    for lo,hi,mesh in ((start,40,1024),(40,100,256),(100,280,64)):
        masses=[(w.numerator,w.denominator*mesh) for w in a]
        def get(i):
            return (sum(i*p//q for p,q in masses),
                    [boxes(i,mesh,classes[k],classes[1-k]) for k in (0,1)])
        H0,prev=get(lo*mesh)
        for i in range(lo*mesh,hi*mesh):
            H1,nxt=get(i+1)
            v=sum(w*phi(n-H1,m) for box in prev for w,n in box if n-H1>m)
            v+=sum(w*phi(n-H0,m) for box in nxt for w,n in box if n<H0)
            if v:
                value+=(v*mesh*(2*i+1)*scale*L.denominator)//(20000*L.numerator*(i*(i+1))**2)
            H0,prev=H1,nxt
    return F(value,scale)

