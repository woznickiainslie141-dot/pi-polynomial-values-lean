"""Scalar verifier for a selected determinant, including locally refined energy witnesses."""
from math import lcm
from functools import lru_cache
from fractions import Fraction as F
from pathlib import Path
import struct
import sys

HERE=Path(__file__).resolve().parent
PRIOR=HERE/"prior"
sys.path[:0]=[str(PRIOR),str(PRIOR/"reference"),str(PRIOR/"reference"/"baseline")]
from scalar_spatial import full as original_full
import json

DENSE=32000
PRIM=40000
GRID=640
S1=10**9
S2=10**12
UNIT=100000
WORD=64


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


@lru_cache(None)
def table(n):
    unit=10**23;lv=[(0,0),(0,0)]
    for i in range(1,2*n):
        t=2*i+1;den=t;k=1;lo,hi=lv[-1]
        while (q:=2*unit//(k*den)):
            lo+=q;hi+=q+1;den*=t*t;k+=2
        lv.append((lo,hi+2))
    f=[0];j=[0]
    for i in range(1,2*n+1):
        low=lv[i][0]+lv[2][0]-lv[n][1];high=lv[i][1]+lv[2][1]-lv[n][0]
        v=i*S1*(low-unit)//(n*unit);w=i*i*S2*(2*low-3*unit)//(4*n*n*unit)
        assert (v+2)*n*unit>=i*S1*(high-unit) and (w+2)*4*n*n*unit>=i*i*S2*(2*high-3*unit)
        f.append(v);j.append(w)
    return [-v for v in f[:0:-1]]+f,j


@lru_cache(None)
def packed_basis():
    f,_=table(DENSE);stride=2*DENSE//GRID
    assert DENSE%stride==0
    shift=max(map(abs,f));rows=[]
    for t in range(stride):
        vals=[v+shift for v in f[t::stride]]
        packed=int.from_bytes(struct.pack("<"+"Q"*len(vals),*vals),"little")
        bias=((1<<(WORD*(len(vals)+GRID)))-1)//((1<<WORD)-1)*(1<<(WORD-1))
        rows.append((packed,bias))
    return shift,stride,rows


def potentials(dr):
    shift,stride,rows=packed_basis()
    assert len(dr)==GRID+1 and sum(dr)==0 and 2*shift*sum(map(abs,dr))<1<<(WORD-1)
    g=sum(v<<(WORD*i) for i,v in enumerate(dr))
    out=[0]*(DENSE+1)
    for t,(p,bias) in enumerate(rows):
        n=(DENSE-t)//stride+1
        # The constant shift cancels on the entire interior convolution.
        v=((p*g+bias)>>(WORD*(3*DENSE//stride))) % (1<<(WORD*n))
        out[t::stride]=[x-(1<<(WORD-1)) for x in struct.unpack("<"+"Q"*n,v.to_bytes(8*n,"little"))]
    return out


def regular_square(dr):
    # The central coefficients of g(X)g*(X) are integer autocorrelations.
    norm=sum(map(abs,dr))
    assert norm**2<1<<(WORD-1)
    a=sum(v<<(WORD*i) for i,v in enumerate(dr))
    b=sum(v<<(WORD*i) for i,v in enumerate(reversed(dr)))
    size=2*GRID+1; bias=((1<<(size*WORD))-1)//((1<<WORD)-1)*(1<<(WORD-1))
    product=a*b+bias
    vals=struct.unpack("<"+"Q"*(GRID+1),((product>>(WORD*GRID))% (1<<(WORD*(GRID+1)))).to_bytes(8*(GRID+1),"little"))
    coefs=[2*(v-(1<<(WORD-1))) for v in vals[1:]]
    J=table(PRIM)[1];step=2*PRIM//GRID
    total=sum(v*J[i*step] for i,v in enumerate(coefs,1))
    # J is enclosed between its stored lower integer and that integer plus two.
    return total+2*sum(max(0,v) for v in coefs)


def jumps(r):
    return [b-a for a,b in zip([0]+r,r+[0])]


def mixed_upper(positions,changes):
    J=table(PRIM)[1]
    terms=[(x,c) for x,c in zip(positions,changes) if c]
    coefs={}
    for i,(x,c) in enumerate(terms):
        for y,b in terms[:i]:
            t=x-y;coefs[t]=coefs.get(t,0)-2*c*b
    return sum(v*J[i]+2*max(0,v) for i,v in coefs.items())


@lru_cache(None)
def get_anchor(d):
    spec=read(PRIOR/f"center{d}.json");data=read(PRIOR/"reference"/f"case{d}.json")
    row=next(r for r in read(PRIOR/f"spatial{d}.json")["ordinary"] if r["label"]==spec["anchor"])
    f,_=original_full(data,row,160)
    return [max(range(len(f)),key=lambda j:f[j][i]+f[j][i+1]) for i in range(10000)]


class Scalar:
    def __init__(self,d,classes,masses):
        self.a=masses;self.L=sum(masses);self.classes=classes
        anchor=get_anchor(d)
        tick=lcm(DENSE,10000);h=tick//DENSE;orig=tick//10000
        all_widths=[k for layer in classes for k in layer]
        cuts=sorted(set(range(0,tick+1,h))|{v*orig for v in all_widths}|
                    {i*orig for i in range(1,10000) if anchor[i]!=anchor[i-1]})
        self.weights=[0]*(DENSE+1);self.mark=[{} for _ in self.weights]
        self.den=4*h*tick
        for l,r in zip(cuts,cuts[1:]):
            i=l//h; weight=sum(2*x*orig>=l+r for x in all_widths)
            a=anchor[l//orig];f=l+r-2*i*h
            for j,m in ((i,2*h-f),(i+1,f)):
                v=(r-l)*m
                self.weights[j]+=v*weight
                self.mark[j][a]=self.mark[j].get(a,0)+v*(weight-4)
        assert F(sum(self.weights),self.den)==self.L
        self.widths=all_widths

    def bounds(self,row,price,others=()):
        edges=row["edges"];m=len(self.a)
        assert edges==[GRID-v for v in edges[::-1]] and edges[0]==0 and edges[-1]==GRID
        assert all(type(v) is int and x<v for x,v in zip(edges,edges[1:]))
        original=row["density"];assert len(original)==(m+1)//2 and original[0]==original[0][::-1]
        half=[]
        for v in original:
            assert len(v)==len(edges)-1 and all(type(x) is int and abs(x)<10**8 for x in v)
            half.append([x for i,x in enumerate(v) for _ in range(edges[i+1]-edges[i])])
        rho=[r[::-1] for r in half[:0:-1]]+half
        b=row["b"][:0:-1]+row["b"];k=[-v for v in row["field"][:0:-1]]+row["field"]
        assert len(k)==len(b)==m and row["field"][0]==0
        fields=[];allj=[];quad=0
        for vals,price0,slope in zip(rho,b,k):
            c=jumps(vals);allj.append(c)
            f=potentials(c);const=-price0*S1+2*sum(map(abs,c))
            # S1 need not be divisible by the independent interpolation mesh.
            # Work with a common extra factor DENSE to retain exact slopes.
            fields.append([DENSE*(v+const)+i*S1*slope for i,v in enumerate(f)])
            quad+=regular_square(c)
        env=list(map(max,zip(*fields)))
        result=[]
        for ctx in (self,*others):
            trap=sum(x*y for x,y in zip(env,ctx.weights))
            if price:
                assert 0<price<=10**8
                fee=price*(UNIT*S1//10**7)*DENSE
                for i,candidates in enumerate(ctx.mark):
                    for a,w in candidates.items():
                        if w:
                            raised=max(f[i]+(0 if j==a else fee) for j,f in enumerate(fields))
                            trap+=w*(raised-env[i])
            # Integrate the signed residual on the common refinement of class widths and density edges.
            step=2*PRIM//GRID; se=set(range(-PRIM,PRIM+1,step))
            se.update((PRIM//10000)*sign*w for w in ctx.widths for sign in (-1,1))
            se=sorted(se);rs=list(map(sum,zip(*rho)))
            residual=[UNIT*sum(2*w*(PRIM//10000)>abs(l+r) for w in ctx.widths)-4*rs[(l+PRIM)//step]
                      for l,r in zip(se,se[1:])]
            corr=min(F(0),F(mixed_upper(se,jumps(residual)),S2*(4*UNIT)**2))/(2*m*ctx.L)
            variation=sum(map(max,zip(*(map(abs,c) for c in allj))))
            error=F(max(map(len,ctx.classes))*variation,UNIT)*F(5+(2*DENSE).bit_length(),4*DENSE**2)
            result.append(((F(trap,ctx.den*UNIT*S1*DENSE)+error+F(quad,2*S2*UNIT**2)
                    +sum(q*v for q,v in zip(ctx.a,b))/UNIT)/ctx.L+corr))
        return result

    def upper(self,row,price):
        return self.bounds(row,price)[0]

