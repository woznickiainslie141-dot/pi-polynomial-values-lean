整系数多项式在圆周率处的值 · 审阅材料

先读 paper/endpoint-proof-zh.pdf。第 2 节给出同一结式的下界，第 7 节给出上界，第 8 节用有理数据比较两者。paper/endpoint-proof-zh.tex 为可独立编译的 XeLaTeX 源码。

复算最后的数值判据
在解压后的顶层目录用 Python 3.11 或更高版本运行

  python -I -S -B research/pi_cross_constant_2026-11-18/diagnostics.py --json recomputed.json

运行只使用标准库。在 recomputed.json 的 cases 里，选 shape 为 current 的二次和三次两条记录。uniform_endpoint 给出 w、b 和主余量的区间。direct_margin 的整数端点须除以 interval_scale（10 的 12 次方）。归档的预期结果为同目录下的 diagnostics.json。

原始数值见证与前稿
打开 research/pi_cross_constant_2026-11-18/base-checkpoint.zip。其根目录、prior/、prior/reference/ 下的三份 CHECKPOINT.md 依次给出等宽频带、扰动价格和素数余数估计。balanced2.json、balanced3.json 及相应的场与角度文件是这一对形状的输入。旧检查点所列指数与最终登记值之间的换算见主文第 8 节。RateData.lean 保存形式证明实际使用的有理输入。

已归档的四项定理的 Lean 传递公理输出在 formalization/OddPiPowers/logs/ 下。完整源码、归档和重放说明在项目仓库中。
https://github.com/woznickiainslie141-dot/pi-polynomial-values-lean
